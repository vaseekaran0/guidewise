import React from 'react';
import { Code2, Cpu, ShieldAlert, Sparkles } from 'lucide-react';
import { EDUCATIONAL_DISCLAIMER } from '../shared/crisprEngine.js';

export const AboutPage: React.FC = () => {
  return (
    <div className="max-w-5xl w-full mx-auto px-4 sm:px-6 py-10 space-y-8">
      <div className="border-b border-[#1b2b37] pb-6 space-y-2">
        <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#e8f3f1] text-balance">
          How GuideWise Works, Scientific Limits &amp; Ethics
        </h1>
        <p className="text-sm sm:text-base text-[#8aa4ad]">
          Built for VITAL X8 (Problem HTH-SW-02) as a transparent, deterministic educational platform for exploring CRISPR-Cas9 sequence matching.
        </p>
      </div>

      {/* Matching Logic */}
      <section className="gw-panel p-6 space-y-4">
        <div className="flex items-center gap-2">
          <Code2 className="w-5 h-5 text-[#2ee6c5]" aria-hidden="true" />
          <h2 className="font-display text-xl font-semibold text-[#e8f3f1]">
            01. Deterministic Matching &amp; Scoring Logic
          </h2>
        </div>

        <div className="space-y-3 text-sm text-[#c7d8d6] leading-relaxed">
          <p>
            Unlike probabilistic black-box tools, GuideWise runs a pure deterministic TypeScript bioinformatics engine on both the client and server:
          </p>
          <ul className="list-disc pl-5 space-y-2">
            <li>
              <strong className="text-[#e8f3f1]">Strict Input Validation:</strong> Strips FASTA headers (<code className="font-mono text-[#2ee6c5]">&gt;</code>) and whitespace, converts RNA <code className="font-mono text-[#2ee6c5]">U</code> to <code className="font-mono text-[#2ee6c5]">T</code>, and rejects any character outside <code className="font-mono text-[#2ee6c5]">A/C/G/T</code>. Guides must be 15–25 bases; synthetic DNA must be at least 30 bases.
            </li>
            <li>
              <strong className="text-[#e8f3f1]">Bidirectional Sliding Window:</strong> Slides a window of length <code className="font-mono">L_guide</code> across both the forward (<code className="font-mono">+</code>) strand and reverse complement (<code className="font-mono">-</code>) strand, calculating Hamming distance (mismatch count) at every offset with space for the 3&apos; PAM.
            </li>
            <li>
              <strong className="text-[#e8f3f1]">PAM Recognition:</strong> Checks the motif immediately 3&apos; of the window against IUPAC rules for <code className="font-mono">NGG</code>, <code className="font-mono">NAG</code>, or <code className="font-mono">NNGRRT</code>. Sites with missing or mismatched PAMs receive an educational score of <code className="font-mono">0.0</code>.
            </li>
            <li>
              <strong className="text-[#e8f3f1]">Seed-Weighted Educational Estimate:</strong> The last 10 bases adjacent to the PAM form the seed region. Each seed mismatch adds penalty <code className="font-mono">3</code>; each upstream mismatch adds penalty <code className="font-mono">1</code>. Score = <code className="font-mono text-[#2ee6c5]">100 × exp(-0.5 × penalty)</code>.
            </li>
            <li>
              <strong className="text-[#e8f3f1]">Cut Coordinate Mapping:</strong> Cleavage is placed 3 bp before the PAM, mapped to 1-based coordinates on the original forward strand (<code className="font-mono">end - 3</code> on <code className="font-mono">+</code>, <code className="font-mono">start + 2</code> on <code className="font-mono">-</code>).
            </li>
          </ul>
        </div>
      </section>

      {/* Scientific Limitations */}
      <section className="gw-panel p-6 space-y-4">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-[#ffb020]" aria-hidden="true" />
          <h2 className="font-display text-xl font-semibold text-[#e8f3f1]">
            02. Educational Scope &amp; Scientific Limitations
          </h2>
        </div>

        <div className="space-y-3 text-sm text-[#c7d8d6] leading-relaxed">
          <p>
            Every score displayed in GuideWise is strictly labelled an <strong className="text-[#e8f3f1]">educational estimate</strong> and is never presented as an experimentally validated prediction. Real biological Cas9 activity depends on many factors outside a short synthetic sequence:
          </p>
          <ul className="list-disc pl-5 space-y-1.5">
            <li>Chromatin accessibility, nucleosome positioning, and DNA methylation state.</li>
            <li>Guide RNA secondary structure, folding stability, and cellular concentration.</li>
            <li>DNA/RNA bulges (indels at the RNA–DNA interface) and non-canonical PAM kinetics.</li>
            <li>Cellular DNA repair preferences (NHEJ vs MMEJ vs HDR), which vary widely by cell type.</li>
          </ul>
        </div>
      </section>

      {/* Ethics & Biosafety */}
      <section className="gw-panel p-6 space-y-4">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-[#ff4d6d]" aria-hidden="true" />
          <h2 className="font-display text-xl font-semibold text-[#e8f3f1]">
            03. Ethics &amp; Biosafety Boundaries
          </h2>
        </div>
        <p className="text-sm text-[#c7d8d6] leading-relaxed">
          GuideWise operates exclusively on synthetic DNA sequences for classroom and hackathon demonstration. The platform includes zero wet-lab protocols, zero reagent recipes, zero delivery vector instructions, and a strict Q&amp;A guardrail that refuses requests involving real human genes, clinical editing, or pathogens.
        </p>
        <div className="rounded-lg border border-[#1b2b37] bg-[#070d12] p-4 text-xs text-[#ffb020]">
          {EDUCATIONAL_DISCLAIMER}
        </div>
      </section>

      {/* 3D Rendering Architecture Note */}
      <section className="gw-panel p-6 space-y-3">
        <div className="flex items-center gap-2">
          <Cpu className="w-5 h-5 text-[#7c5cff]" aria-hidden="true" />
          <h2 className="font-display text-xl font-semibold text-[#e8f3f1]">
            04. Browser 3D Rendering vs. Offline Cinematics
          </h2>
        </div>
        <p className="text-sm text-[#c7d8d6] leading-relaxed">
          Because Unreal Engine cannot run natively inside an offline web browser sandbox, GuideWise achieves realistic glossy ball-and-stick DNA visuals locally using <strong className="text-[#e8f3f1]">Three.js</strong> with physically based clearcoat materials (<code className="font-mono">MeshPhysicalMaterial</code>), procedural studio environment lighting (<code className="font-mono">RoomEnvironment</code>), exponential depth fog, and orbit damping—all bundled locally for offline reliability. For museum exhibits or broadcast video, the same base-pair coordinates and Cas9 keyframe path could separately be exported as Alembic/glTF meshes to render an offline cinematic in Unreal Engine with Lumen and Nanite.
        </p>
      </section>
    </div>
  );
};
