import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Play, Scissors, Search, ShieldCheck } from 'lucide-react';
import { DnaHelixViewport } from '../components/DnaHelixViewport.js';
import { analyzeGuideAgainstDna, TEST_VECTOR } from '../shared/crisprEngine.js';
import { AppPage } from '../types/crispr.js';

interface LandingPageProps {
  onLaunchSimulator: () => void;
  onWatchDemo: () => void;
  onNavigate: (page: AppPage) => void;
}

const HOW_IT_WORKS = [
  {
    step: '01. Match',
    title: 'Scan both DNA strands',
    description:
      'A sliding window equal to your 15–25 nt guide RNA scans forward (+) and reverse complement (-) strands, counting base mismatches via Hamming distance.',
    detail: 'Seed-weighted: last 10 bases near PAM carry 3× penalty.',
    Icon: Search,
  },
  {
    step: '02. PAM check',
    title: 'Verify 3′ PAM recognition',
    description:
      'Cas9 must recognize a Protospacer Adjacent Motif (NGG, NAG, or NNGRRT) immediately 3′ of the target window. Without a valid PAM, the site scores 0.0.',
    detail: 'Even 0-mismatch matches cannot cut without a valid PAM.',
    Icon: ShieldCheck,
  },
  {
    step: '03. Cut',
    title: 'Model cleavage & indels',
    description:
      'At valid targets, cleavage is modelled 3 bp upstream of the PAM, with illustration-only 1-bp deletion and insertion previews showing frameshifts.',
    detail: '1-based original-strand coordinates for every site.',
    Icon: Scissors,
  },
];

export const LandingPage: React.FC<LandingPageProps> = ({
  onLaunchSimulator,
  onWatchDemo,
  onNavigate,
}) => {
  const demoAnalysis = useMemo(
    () =>
      analyzeGuideAgainstDna(
        TEST_VECTOR.dna,
        TEST_VECTOR.guide,
        TEST_VECTOR.pam,
        TEST_VECTOR.maxMm
      ),
    []
  );

  return (
    <div className="flex flex-col">
      {/* Full-Screen Animated 3D DNA Helix Hero */}
      <section className="relative min-h-[calc(100vh-110px)] flex items-center overflow-hidden border-b border-[#1b2b37]">
        {/* 3D Canvas Backdrop */}
        <div className="absolute inset-0 z-0">
          <DnaHelixViewport
            dna={TEST_VECTOR.dna}
            sites={demoAnalysis.sites}
            selectedSiteIndex={0}
            mode="hero"
            autoPlay
            className="w-full h-full rounded-none border-0"
          />
          {/* Measured Scrim for WCAG Contrast */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background:
                'linear-gradient(90deg, rgba(7,13,18,0.92) 0%, rgba(7,13,18,0.74) 48%, rgba(7,13,18,0.28) 100%)',
            }}
          />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 max-w-7xl mx-auto w-full px-4 sm:px-6 py-16 lg:py-24">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="max-w-2xl space-y-7"
          >
            {/* Quiet Unboxed Trust Metadata */}
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs sm:text-sm font-medium text-[#2ee6c5]">
              <span>Synthetic data</span>
              <span className="text-[#8aa4ad]" aria-hidden="true">·</span>
              <span>Educational estimates</span>
              <span className="text-[#8aa4ad]" aria-hidden="true">·</span>
              <span>No real editing</span>
            </div>

            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#e8f3f1] leading-[1.08] text-balance">
              See how <span className="gw-gradient-text">CRISPR</span> finds its target
            </h1>

            <p className="text-base sm:text-lg text-[#c7d8d6] leading-relaxed max-w-xl">
              Explore guide RNA matching, 3′ PAM recognition, seed-weighted mismatch scoring, and hypothetical cleavage on synthetic DNA sequences inside a real-time 3D molecular viewport.
            </p>

            {/* Primary Actions */}
            <div className="flex flex-wrap items-center gap-4 pt-1">
              <button
                type="button"
                onClick={onLaunchSimulator}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-sm sm:text-base font-semibold gw-gradient-btn transition-all cursor-pointer whitespace-nowrap"
              >
                Launch simulator
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>

              <button
                type="button"
                onClick={onWatchDemo}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-sm sm:text-base font-semibold border border-[#1b2b37] bg-[#0e1922]/90 text-[#e8f3f1] hover:border-[#2ee6c5]/60 transition-colors cursor-pointer whitespace-nowrap"
              >
                <Play className="w-4 h-4 text-[#2ee6c5]" aria-hidden="true" />
                Watch demo
              </button>
            </div>

            {/* Concrete Verification Strip (Claim-to-Proof Adjacency) */}
            <div className="pt-4 border-t border-[#1b2b37]/80 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <div className="text-[#8aa4ad]">On-target test site</div>
                <div className="font-mono text-sm font-semibold text-[#3ddc84] tabular-nums mt-0.5">
                  14–33 bp · Score 100.0
                </div>
              </div>
              <div>
                <div className="text-[#8aa4ad]">Seed + distal mismatch</div>
                <div className="font-mono text-sm font-semibold text-[#ffb020] tabular-nums mt-0.5">
                  47–66 bp · Score 13.5
                </div>
              </div>
              <div>
                <div className="text-[#8aa4ad]">Missing PAM control</div>
                <div className="font-mono text-sm font-semibold text-[#8aa4ad] tabular-nums mt-0.5">
                  80–99 bp · PAM TCA (0.0)
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* How It Works — 3 Animated Editorial Cards */}
      <section className="max-w-7xl mx-auto w-full px-4 sm:px-6 py-16 lg:py-20 space-y-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="space-y-2 max-w-2xl">
            <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#e8f3f1] text-balance">
              Three deterministic steps from sequence to cleavage
            </h2>
            <p className="text-sm sm:text-base text-[#8aa4ad]">
              Every match is computed by transparent bioinformatics code—never guessed—so students can trace every mismatch, PAM motif, and cut coordinate.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('learn')}
            className="text-sm font-medium text-[#2ee6c5] hover:underline self-start md:self-auto whitespace-nowrap cursor-pointer"
          >
            Read beginner concepts &amp; Q&amp;A →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {HOW_IT_WORKS.map((item, idx) => {
            const Icon = item.Icon;
            return (
              <motion.article
                key={item.step}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.35, delay: idx * 0.08, ease: [0.16, 1, 0.3, 1] }}
                className="gw-panel gw-panel-interactive p-6 flex flex-col justify-between gap-5"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-semibold text-[#2ee6c5]">
                      {item.step}
                    </span>
                    <Icon className="w-5 h-5 text-[#8aa4ad]" aria-hidden="true" />
                  </div>
                  <h3 className="font-display text-xl font-semibold text-[#e8f3f1]">
                    {item.title}
                  </h3>
                  <p className="text-sm text-[#c7d8d6] leading-relaxed">{item.description}</p>
                </div>
                <div className="pt-4 border-t border-[#1b2b37] text-xs font-mono text-[#8aa4ad]">
                  {item.detail}
                </div>
              </motion.article>
            );
          })}
        </div>
      </section>
    </div>
  );
};
