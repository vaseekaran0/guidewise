import React, { useState } from 'react';
import { Menu, ShieldAlert, X } from 'lucide-react';
import { EDUCATIONAL_DISCLAIMER } from '../shared/crisprEngine.js';
import type { AppPage } from '../types/crispr.js';

interface LayoutProps {
  currentPage: AppPage;
  onNavigate: (page: AppPage) => void;
  children: React.ReactNode;
}

const NAV_ITEMS: Array<{ id: AppPage; label: string }> = [
  { id: 'simulator', label: 'Simulator' },
  { id: 'compare', label: 'Compare' },
  { id: 'learn', label: 'Learn & Q&A' },
  { id: 'reports', label: 'Reports' },
  { id: 'about', label: 'About' },
];

export const Layout: React.FC<LayoutProps> = ({ currentPage, onNavigate, children }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNav = (page: AppPage) => {
    setMobileMenuOpen(false);
    onNavigate(page);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#070d12] text-[#e8f3f1]">
      {/* Permanent Educational Disclaimer Banner (non-sticky so mobile sticky height stays minimal) */}
      <div
        role="note"
        aria-label="Educational Simulation Disclaimer"
        className="w-full bg-[#0b141c] border-b border-[#1b2b37] px-4 py-2 text-xs text-[#c7d8d6]"
      >
        <div className="max-w-7xl mx-auto flex items-center justify-center gap-2 text-center leading-relaxed">
          <ShieldAlert className="w-3.5 h-3.5 text-[#ffb020] shrink-0" aria-hidden="true" />
          <span>{EDUCATIONAL_DISCLAIMER}</span>
        </div>
      </div>

      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-40 w-full bg-[#070d12]/95 border-b border-[#1b2b37]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single text element wordmark */}
          <button
            type="button"
            onClick={() => handleNav('landing')}
            className="font-display text-xl font-bold tracking-tight text-[#e8f3f1] hover:text-[#2ee6c5] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            GuideWise
          </button>

          {/* Zone 2: 5 concise single-line text navigation links */}
          <nav aria-label="Primary navigation" className="hidden md:flex items-center gap-7">
            {NAV_ITEMS.map((item) => {
              const active = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleNav(item.id)}
                  aria-current={active ? 'page' : undefined}
                  className={`text-sm font-medium transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 cursor-pointer ${
                    active
                      ? 'text-[#2ee6c5] border-[#2ee6c5]'
                      : 'text-[#8aa4ad] border-transparent hover:text-[#e8f3f1] hover:border-[#1b2b37]'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 primary action + mobile menu toggle */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => handleNav('simulator')}
              className="hidden sm:inline-flex items-center justify-center px-4 py-2 rounded-lg text-sm font-semibold gw-gradient-btn transition-all whitespace-nowrap shrink-0 cursor-pointer"
            >
              Launch simulator
            </button>
            <button
              type="button"
              onClick={() => setMobileMenuOpen((prev) => !prev)}
              aria-expanded={mobileMenuOpen}
              aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
              className="md:hidden p-2 rounded-lg border border-[#1b2b37] text-[#e8f3f1] hover:border-[#2ee6c5]/50 cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <nav
            aria-label="Mobile navigation"
            className="md:hidden border-t border-[#1b2b37] bg-[#0e1922] px-4 py-3 flex flex-col gap-1"
          >
            <button
              type="button"
              onClick={() => handleNav('landing')}
              className={`text-left px-3 py-2.5 rounded-lg text-sm font-medium ${
                currentPage === 'landing' ? 'text-[#2ee6c5] bg-[#070d12]' : 'text-[#8aa4ad]'
              }`}
            >
              Home
            </button>
            {NAV_ITEMS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNav(item.id)}
                className={`text-left px-3 py-2.5 rounded-lg text-sm font-medium ${
                  currentPage === item.id ? 'text-[#2ee6c5] bg-[#070d12]' : 'text-[#8aa4ad]'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col">{children}</main>

      {/* Clean Educational Footer */}
      <footer className="border-t border-[#1b2b37] bg-[#070d12] py-8 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-xs text-[#8aa4ad]">
          <div className="space-y-1">
            <div className="font-display text-sm font-semibold text-[#e8f3f1]">
              GuideWise · Educational CRISPR-Cas9 Simulation
            </div>
            <p>
              Synthetic DNA sequences only · Deterministic matching logic · Off-target scores are educational estimates.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-5">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNav(item.id)}
                className="hover:text-[#e8f3f1] transition-colors whitespace-nowrap cursor-pointer"
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
};
