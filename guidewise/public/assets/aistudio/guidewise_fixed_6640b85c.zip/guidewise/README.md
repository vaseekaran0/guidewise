# GuideWise (educational CRISPR simulator, synthetic DNA only)

## Run (VS Code terminal)
1. Install Node.js 20+ from nodejs.org (once, needs internet).
2. `npm install`   (a .npmrc is included, so no extra flags are needed)
3. `npm run dev`
4. Open http://localhost:3000

Optional: copy `.env.example` to `.env.local` and set GEMINI_API_KEY to let the Q&A assistant rephrase answers.
Without a key the assistant works fully offline from its built-in knowledge base.

## Check
`npm test` runs 8 engine tests (official test vector, validation, reverse strand, PAMs, edit, Q&A safety).

## Pages
Landing, Simulator, Compare, Learn and Q&A, Reports, About.
