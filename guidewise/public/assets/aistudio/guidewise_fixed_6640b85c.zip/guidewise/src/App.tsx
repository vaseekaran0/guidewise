import { useEffect, useState } from 'react';
import { AnimatePresence, motion, MotionConfig } from 'motion/react';
import { Layout } from './components/Layout.js';
import { AboutPage } from './pages/AboutPage.js';
import { ComparePage } from './pages/ComparePage.js';
import { LandingPage } from './pages/LandingPage.js';
import { LearnPage } from './pages/LearnPage.js';
import { ReportsPage } from './pages/ReportsPage.js';
import { SimulatorPage } from './pages/SimulatorPage.js';
import { TEST_VECTOR } from './shared/crisprEngine.js';
import { AnalyzeApiResponse, AppPage, PamType } from './types/crispr.js';

const VALID_PAGES: AppPage[] = ['landing', 'simulator', 'compare', 'learn', 'reports', 'about'];

function pageFromHash(): AppPage {
  if (typeof window === 'undefined') return 'landing';
  const raw = window.location.hash.replace(/^#\/?/, '').toLowerCase() as AppPage;
  return VALID_PAGES.includes(raw) ? raw : 'landing';
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<AppPage>(() => pageFromHash());
  const [latestRun, setLatestRun] = useState<AnalyzeApiResponse | null>(null);

  const [simulatorPreset, setSimulatorPreset] = useState<{
    dna?: string;
    guide?: string;
    pam?: PamType;
    maxMm?: number;
    autoPlay?: boolean;
  } | null>(null);

  const [comparePreset, setComparePreset] = useState<{
    dna: string;
    guides: string[];
    pam: PamType;
    maxMm: number;
  } | null>(null);

  useEffect(() => {
    const onHashChange = () => {
      setCurrentPage(pageFromHash());
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const navigate = (page: AppPage) => {
    setCurrentPage(page);
    if (typeof window !== 'undefined') {
      const targetHash = page === 'landing' ? '#/' : `#/${page}`;
      if (window.location.hash !== targetHash) {
        window.location.hash = targetHash;
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleLaunchSimulator = () => {
    setSimulatorPreset({
      dna: TEST_VECTOR.dna,
      guide: TEST_VECTOR.guide,
      pam: TEST_VECTOR.pam,
      maxMm: TEST_VECTOR.maxMm,
      autoPlay: false,
    });
    navigate('simulator');
  };

  const handleWatchDemo = () => {
    setSimulatorPreset({
      dna: TEST_VECTOR.dna,
      guide: TEST_VECTOR.guide,
      pam: TEST_VECTOR.pam,
      maxMm: TEST_VECTOR.maxMm,
      autoPlay: true,
    });
    navigate('simulator');
  };

  const handleSendToCompare = (dna: string, guide: string, pam: PamType, maxMm: number) => {
    setComparePreset({
      dna,
      guides: [guide, 'TGGCCATTAGCATGATGCGT', 'GATCCGTAACGGTTCATCTA'],
      pam,
      maxMm,
    });
    navigate('compare');
  };

  const handleReloadInSimulator = (dna: string, guide: string, pam: PamType, maxMm: number) => {
    setSimulatorPreset({ dna, guide, pam, maxMm, autoPlay: true });
    navigate('simulator');
  };

  return (
    <MotionConfig reducedMotion="user">
      <Layout currentPage={currentPage} onNavigate={navigate}>
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="flex-1 flex flex-col"
          >
            {currentPage === 'landing' && (
              <LandingPage
                onLaunchSimulator={handleLaunchSimulator}
                onWatchDemo={handleWatchDemo}
                onNavigate={navigate}
              />
            )}
            {currentPage === 'simulator' && (
              <SimulatorPage
                initialState={simulatorPreset}
                onAnalysisComplete={(res) => setLatestRun(res)}
                onSendToCompare={handleSendToCompare}
                onNavigate={navigate}
              />
            )}
            {currentPage === 'compare' && (
              <ComparePage
                initialCompare={comparePreset}
                onLoadInSimulator={handleReloadInSimulator}
              />
            )}
            {currentPage === 'learn' && <LearnPage latestRun={latestRun} />}
            {currentPage === 'reports' && (
              <ReportsPage onReloadRunInSimulator={handleReloadInSimulator} />
            )}
            {currentPage === 'about' && <AboutPage />}
          </motion.div>
        </AnimatePresence>
      </Layout>
    </MotionConfig>
  );
}
