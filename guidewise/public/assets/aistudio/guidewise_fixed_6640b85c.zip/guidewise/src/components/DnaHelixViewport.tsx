import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  ChevronDown,
  ChevronUp,
  Eye,
  Pause,
  Play,
  RotateCcw,
  SkipForward,
  Sparkles,
} from 'lucide-react';
import { SiteMatch } from '../types/crispr.js';

interface DnaHelixViewportProps {
  dna: string;
  sites: SiteMatch[];
  selectedSiteIndex: number | null;
  onSelectSite?: (index: number) => void;
  mode?: 'hero' | 'simulator';
  reducedMotion?: boolean;
  onToggleReducedMotion?: () => void;
  autoPlay?: boolean;
  className?: string;
}

const BASE_COLORS: Record<string, number> = {
  A: 0xff5d8f,
  T: 0xffb020,
  G: 0x3ddc84,
  C: 0x4cc9ff,
};

const COMPLEMENT: Record<string, string> = {
  A: 'T',
  T: 'A',
  G: 'C',
  C: 'G',
};

const CATEGORY_COLORS = {
  'on-target': 0x3ddc84,
  'near-match': 0xffb020,
  'high-mismatch': 0xff4d6d,
  'no-pam': 0x64748b,
  pam: 0x7c5cff,
  mismatchBase: 0xff2a55,
};

// Reusable math objects outside animation loop (zero per-frame GC)
const _vA = new THREE.Vector3();
const _vB = new THREE.Vector3();
const _mid = new THREE.Vector3();
const _dir = new THREE.Vector3();
const _up = new THREE.Vector3(0, 1, 0);
const _quat = new THREE.Quaternion();
const _targetCamPos = new THREE.Vector3();
const _targetCtrl = new THREE.Vector3();

interface BpNode {
  bpIndex1: number;
  baseFwd: string;
  baseRev: string;
  y: number;
  angle: number;
  group: THREE.Group;
  fwdSide: THREE.Group;
  revSide: THREE.Group;
  fwdBaseMesh: THREE.Mesh;
  revBaseMesh: THREE.Mesh;
  fwdBackboneMesh: THREE.Mesh;
  revBackboneMesh: THREE.Mesh;
  rungMesh: THREE.Mesh;
  ringMarker: THREE.Mesh;
}

function detectSoftwareWebGL(): boolean {
  try {
    const probeCanvas = document.createElement('canvas');
    const gl = probeCanvas.getContext('webgl2') || probeCanvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) || '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export const DnaHelixViewport: React.FC<DnaHelixViewportProps> = ({
  dna,
  sites,
  selectedSiteIndex,
  onSelectSite,
  mode = 'simulator',
  reducedMotion: externalReducedMotion,
  onToggleReducedMotion,
  autoPlay = false,
  className = '',
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [webglError, setWebglError] = useState<string | null>(null);
  const [internalReducedMotion, setInternalReducedMotion] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
    return false;
  });

  const reducedMotion = externalReducedMotion ?? internalReducedMotion;
  const toggleReducedMotion =
    onToggleReducedMotion ?? (() => setInternalReducedMotion((prev) => !prev));

  const [isPlaying, setIsPlaying] = useState<boolean>(autoPlay || mode === 'hero');
  const [dockCollapsed, setDockCollapsed] = useState<boolean>(false);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);
  const [caption, setCaption] = useState<string>(
    mode === 'hero'
      ? 'Cas9 + guide RNA scanning double-stranded synthetic DNA for 3\' PAM motifs.'
      : 'Press Play to watch the Cas9 + guide RNA bubble scan the duplex and test PAM + seed pairing.'
  );
  const [activeScanBp, setActiveScanBp] = useState<number>(1);

  // Determine 1-based slice window for very long sequences (> 130 bp) so 3D remains sharp
  const maxRenderBp = 130;
  const activeSite = selectedSiteIndex !== null ? sites[selectedSiteIndex] ?? null : null;
  let sliceStart1 = 1;
  let sliceEnd1 = dna.length;
  if (dna.length > maxRenderBp) {
    const focusCenter = activeSite ? Math.round((activeSite.start + activeSite.end) / 2) : 65;
    sliceStart1 = Math.max(1, focusCenter - Math.floor(maxRenderBp / 2));
    sliceEnd1 = Math.min(dna.length, sliceStart1 + maxRenderBp - 1);
    if (sliceEnd1 - sliceStart1 + 1 < maxRenderBp) {
      sliceStart1 = Math.max(1, sliceEnd1 - maxRenderBp + 1);
    }
  }
  const visibleDna = dna.slice(sliceStart1 - 1, sliceEnd1);

  // Keep mutable simulation refs accessible to the single persistent Three.js animation loop
  const simStateRef = useRef({
    isPlaying,
    reducedMotion,
    speedMultiplier,
    sites,
    selectedSiteIndex,
    sliceStart1,
    sliceEnd1,
    visibleLength: visibleDna.length,
    scanProgress: 0, // 0..1 across visibleDna
    dwellTimer: 0,
    cutAnim: 0, // 0..1 strand separation amount
    userInteracting: false,
    cameraFollow: mode === 'simulator',
    mode,
    lastCaption: '',
    lastBpReported: 1,
    resetCameraRequested: false,
    stepSiteRequested: false,
  });

  simStateRef.current.isPlaying = isPlaying;
  simStateRef.current.reducedMotion = reducedMotion;
  simStateRef.current.speedMultiplier = speedMultiplier;
  simStateRef.current.sites = sites;
  simStateRef.current.selectedSiteIndex = selectedSiteIndex;
  simStateRef.current.sliceStart1 = sliceStart1;
  simStateRef.current.sliceEnd1 = sliceEnd1;
  simStateRef.current.visibleLength = visibleDna.length;
  simStateRef.current.mode = mode;

  // When user clicks a site in the table, jump scanner smoothly to that site
  useEffect(() => {
    if (selectedSiteIndex === null) return;
    const site = sites[selectedSiteIndex];
    if (!site) return;
    const centerBp = (site.start + site.end) / 2;
    const denom = Math.max(1, simStateRef.current.visibleLength - 1);
    const norm = THREE.MathUtils.clamp((centerBp - simStateRef.current.sliceStart1) / denom, 0, 1);
    simStateRef.current.scanProgress = norm;
    simStateRef.current.dwellTimer = site.pamOk && site.mismatches <= 2 ? 1.8 : 0.6;
    simStateRef.current.cameraFollow = true;
  }, [selectedSiteIndex, sites]);

  // Persistent Three.js Scene + Renderer Lifecycle (rebuilds helix group when visibleDna changes)
  const sceneObjectsRef = useRef<{
    scene: THREE.Scene;
    helixRoot: THREE.Group;
    bpNodes: BpNode[];
    cas9Group: THREE.Group;
    cas9RecMesh: THREE.Mesh;
    cas9NucMesh: THREE.Mesh;
    cas9PamMesh: THREE.Mesh;
    cas9RnaMesh: THREE.Mesh;
    cutRing: THREE.Mesh;
    camera: THREE.PerspectiveCamera;
    controls: OrbitControls;
    helixStepY: number;
    helixHalfHeight: number;
  } | null>(null);

  // Initialize Three.js WebGLRenderer once
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareWebGL();
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglError('WebGL is unavailable in this browser context. Use the 2D sequence alignment and track map below.');
      return;
    }

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const width = Math.max(container.clientWidth, 320);
    const height = Math.max(container.clientHeight, 260);
    renderer.setSize(width, height);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      setWebglError('3D WebGL context was interrupted. Reload or switch to 2D alignment view.');
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x070d12);
    scene.fog = new THREE.FogExp2(0x070d12, mode === 'hero' ? 0.016 : 0.014);

    // Mandatory Studio Environment Map (RoomEnvironment)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTex = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(44, width / height, 0.1, 240);
    camera.position.set(mode === 'hero' ? 14 : 16, 4, mode === 'hero' ? 18 : 20);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.06;
    controls.minDistance = 7;
    controls.maxDistance = 65;
    controls.enablePan = true;
    controls.enableZoom = mode !== 'hero';
    controls.addEventListener('start', () => {
      simStateRef.current.userInteracting = true;
      simStateRef.current.cameraFollow = false;
    });
    controls.addEventListener('end', () => {
      simStateRef.current.userInteracting = false;
    });

    // 3-Point Studio Lighting Rig
    const hemiLight = new THREE.HemisphereLight(0x7dd3fc, 0x09131c, 0.65);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff1e0, 1.85);
    keyLight.position.set(16, 22, 18);
    if (!isSoftwareGl) {
      keyLight.castShadow = true;
      keyLight.shadow.mapSize.set(1024, 1024);
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x2ee6c5, 1.15);
    rimLight.position.set(-18, -6, -16);
    scene.add(rimLight);

    const violetAccent = new THREE.PointLight(0x7c5cff, 1.4, 48, 1.5);
    violetAccent.position.set(0, 0, 12);
    scene.add(violetAccent);

    const helixRoot = new THREE.Group();
    // Orient helix horizontally for hero mode, slight architectural tilt for simulator
    if (mode === 'hero') {
      helixRoot.rotation.z = -Math.PI / 3.4;
      helixRoot.rotation.x = 0.18;
    } else {
      helixRoot.rotation.z = -Math.PI / 2.25;
      helixRoot.rotation.x = 0.12;
    }
    scene.add(helixRoot);

    // Composite 4-part Translucent Cas9 + Guide RNA Ribonucleoprotein Complex
    const cas9Group = new THREE.Group();
    const cas9BubbleMat = new THREE.MeshPhysicalMaterial({
      color: 0x2ee6c5,
      emissive: 0x0b3b36,
      emissiveIntensity: 0.45,
      roughness: 0.22,
      metalness: 0.05,
      transparent: true,
      opacity: isSoftwareGl ? 0.28 : 0.24,
      transmission: isSoftwareGl ? 0 : 0.45,
      thickness: 1.8,
      ior: 1.42,
      clearcoat: 1.0,
      depthWrite: false,
    });

    const cas9NucMat = new THREE.MeshPhysicalMaterial({
      color: 0x4cc9ff,
      emissive: 0x0b253a,
      emissiveIntensity: 0.35,
      roughness: 0.28,
      metalness: 0.08,
      transparent: true,
      opacity: 0.26,
      clearcoat: 0.8,
      depthWrite: false,
    });

    const cas9PamMat = new THREE.MeshPhysicalMaterial({
      color: 0x7c5cff,
      emissive: 0x3b1f99,
      emissiveIntensity: 0.5,
      roughness: 0.25,
      metalness: 0.1,
      transparent: true,
      opacity: 0.34,
      depthWrite: false,
    });

    // Part 1: REC Recognition Lobe
    const cas9RecMesh = new THREE.Mesh(new THREE.SphereGeometry(3.3, 28, 22), cas9BubbleMat);
    cas9RecMesh.scale.set(1.08, 1.45, 0.95);
    cas9RecMesh.position.set(0.4, 0.4, 0);
    cas9RecMesh.renderOrder = 4;
    cas9Group.add(cas9RecMesh);

    // Part 2: NUC Nuclease Lobe (positioned near the -3 cut zone)
    const cas9NucMesh = new THREE.Mesh(new THREE.SphereGeometry(2.45, 24, 20), cas9NucMat);
    cas9NucMesh.scale.set(1.05, 1.1, 1.0);
    cas9NucMesh.position.set(-0.55, -0.8, 0.2);
    cas9NucMesh.renderOrder = 4;
    cas9Group.add(cas9NucMesh);

    // Part 3: PAM-Interacting Domain collar at 3' edge
    const cas9PamMesh = new THREE.Mesh(new THREE.TorusGeometry(2.35, 0.26, 14, 42), cas9PamMat);
    cas9PamMesh.rotation.x = Math.PI / 2;
    cas9PamMesh.position.set(0, 2.55, 0);
    cas9PamMesh.renderOrder = 5;
    cas9Group.add(cas9PamMesh);

    // Part 4: Guide RNA helical ribbon inside Cas9 bubble
    const rnaCurvePts: THREE.Vector3[] = [];
    for (let k = 0; k <= 24; k++) {
      const t = k / 24;
      const ang = t * Math.PI * 2.2;
      rnaCurvePts.push(new THREE.Vector3(Math.cos(ang) * 1.1, (t - 0.5) * 4.4, Math.sin(ang) * 1.1));
    }
    const rnaCurve = new THREE.CatmullRomCurve3(rnaCurvePts);
    const cas9RnaMesh = new THREE.Mesh(
      new THREE.TubeGeometry(rnaCurve, 36, 0.14, 10, false),
      new THREE.MeshStandardMaterial({
        color: 0x2ee6c5,
        emissive: 0x2ee6c5,
        emissiveIntensity: 0.75,
        roughness: 0.2,
        metalness: 0.2,
      })
    );
    cas9Group.add(cas9RnaMesh);

    // Cleavage Ring Indicator at cut plane
    const cutRing = new THREE.Mesh(
      new THREE.TorusGeometry(2.75, 0.08, 12, 48),
      new THREE.MeshStandardMaterial({
        color: 0x3ddc84,
        emissive: 0x3ddc84,
        emissiveIntensity: 1.2,
        roughness: 0.15,
        transparent: true,
        opacity: 0.0,
      })
    );
    cutRing.rotation.x = Math.PI / 2;
    cutRing.position.set(0, 0.7, 0);
    cas9Group.add(cutRing);

    helixRoot.add(cas9Group);

    sceneObjectsRef.current = {
      scene,
      helixRoot,
      bpNodes: [],
      cas9Group,
      cas9RecMesh,
      cas9NucMesh,
      cas9PamMesh,
      cas9RnaMesh,
      cutRing,
      camera,
      controls,
      helixStepY: 0.56,
      helixHalfHeight: 10,
    };

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // Resize observer
    const handleResize = () => {
      if (!container) return;
      const w = Math.max(container.clientWidth, 280);
      const h = Math.max(container.clientHeight, 220);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    const resizeObs = new ResizeObserver(handleResize);
    resizeObs.observe(container);

    // Animation loop with Software-WebGL pacing
    let frameId = 0;
    let disposed = false;
    let lastTime = performance.now();

    function afterDraw(cb: () => void) {
      if (disposed) return;
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl || typeof gl.fenceSync !== 'function') {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) {
          if (sync) gl.deleteSync(sync);
          return;
        }
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick(now: number) {
      if (disposed) return;
      const dt = Math.min(0.08, Math.max(0.001, (now - lastTime) / 1000));
      lastTime = now;

      const objs = sceneObjectsRef.current;
      const st = simStateRef.current;

      if (objs && objs.bpNodes.length > 0) {
        const bpCount = objs.bpNodes.length;
        const stepY = objs.helixStepY;
        const halfH = objs.helixHalfHeight;

        // Handle manual camera reset
        if (st.resetCameraRequested) {
          st.resetCameraRequested = false;
          st.cameraFollow = st.mode === 'simulator';
          _targetCamPos.set(st.mode === 'hero' ? 14 : 16, 4, st.mode === 'hero' ? 18 : 20);
          camera.position.copy(_targetCamPos);
          controls.target.set(0, 0, 0);
          controls.update();
        }

        // Advance scanning along the helix
        if (st.isPlaying) {
          if (st.dwellTimer > 0) {
            st.dwellTimer = Math.max(0, st.dwellTimer - dt * st.speedMultiplier);
          } else {
            const scanRate = (st.mode === 'hero' ? 0.085 : 0.11) * st.speedMultiplier;
            st.scanProgress += dt * scanRate * (st.reducedMotion ? 0.35 : 1);
            if (st.scanProgress > 1) st.scanProgress = 0;
          }
        }

        const currentIdx = Math.min(
          bpCount - 1,
          Math.max(0, Math.round(st.scanProgress * Math.max(1, bpCount - 1)))
        );
        const currentBp1 = objs.bpNodes[currentIdx].bpIndex1;

        if (currentBp1 !== st.lastBpReported) {
          st.lastBpReported = currentBp1;
          setActiveScanBp(currentBp1);
        }

        // Find site matching current scan position (or selected site)
        let activeFocusSite: SiteMatch | null = null;
        if (st.selectedSiteIndex !== null && st.sites[st.selectedSiteIndex]) {
          const sel = st.sites[st.selectedSiteIndex];
          const center = (sel.start + sel.end) / 2;
          if (Math.abs(currentBp1 - center) <= 12) {
            activeFocusSite = sel;
          }
        }
        if (!activeFocusSite) {
          for (const s of st.sites) {
            if (currentBp1 >= s.start && currentBp1 <= s.end) {
              activeFocusSite = s;
              break;
            }
          }
        }

        // Trigger cut strand-separation animation when Cas9 dwells on a valid PAM site
        const shouldCleave =
          Boolean(activeFocusSite && activeFocusSite.pamOk && activeFocusSite.mismatches <= 2) &&
          (st.dwellTimer > 0 || !st.isPlaying);

        const targetCutAnim = shouldCleave ? 1 : 0;
        st.cutAnim = st.reducedMotion
          ? targetCutAnim
          : THREE.MathUtils.damp(st.cutAnim, targetCutAnim, 5.5, dt);

        // Position Cas9 + guide RNA bubble smoothly along local Y axis of helixRoot
        const targetLocalY = (currentIdx / Math.max(1, bpCount - 1) - 0.5) * (halfH * 2);
        objs.cas9Group.position.y = st.reducedMotion
          ? targetLocalY
          : THREE.MathUtils.damp(objs.cas9Group.position.y, targetLocalY, 6.5, dt);

        if (!st.reducedMotion) {
          objs.cas9RnaMesh.rotation.y += dt * 1.2;
        }

        // Update Cas9 color & caption based on site evaluation
        let nextCaption = 'Cas9 + guide RNA bubble scanning the synthetic DNA duplex...';
        const recMat = objs.cas9RecMesh.material as THREE.MeshPhysicalMaterial;
        const cutRingMat = objs.cutRing.material as THREE.MeshStandardMaterial;

        if (activeFocusSite) {
          if (!activeFocusSite.pamOk) {
            recMat.color.setHex(CATEGORY_COLORS['no-pam']);
            cutRingMat.opacity = 0;
            nextCaption = `Base ${activeFocusSite.start}-${activeFocusSite.end}: ${activeFocusSite.mismatches} mismatches, but PAM "${activeFocusSite.pam}" is invalid (no PAM -> score 0.0). Cas9 continues scanning.`;
          } else if (activeFocusSite.mismatches === 0) {
            recMat.color.setHex(CATEGORY_COLORS['on-target']);
            cutRingMat.opacity = 0.85 * st.cutAnim;
            cutRingMat.color.setHex(0x3ddc84);
            nextCaption = `On-target match at ${activeFocusSite.start}-${activeFocusSite.end} (${activeFocusSite.strand} strand): valid PAM ${activeFocusSite.pam}, 0 mismatches, educational score 100.0. Strands separate at cut after base ${activeFocusSite.cut}.`;
          } else if (activeFocusSite.mismatches <= 2) {
            recMat.color.setHex(CATEGORY_COLORS['near-match']);
            cutRingMat.opacity = 0.55 * st.cutAnim;
            cutRingMat.color.setHex(0xffb020);
            nextCaption = `Potential off-target at ${activeFocusSite.start}-${activeFocusSite.end}: ${activeFocusSite.mismatches} mismatch(es) at guide pos ${activeFocusSite.mismatchPositions.join(', ')}, PAM ${activeFocusSite.pam}, educational score ${activeFocusSite.score.toFixed(1)}.`;
          } else {
            recMat.color.setHex(CATEGORY_COLORS['high-mismatch']);
            cutRingMat.opacity = 0;
            nextCaption = `Low-affinity site at ${activeFocusSite.start}-${activeFocusSite.end}: ${activeFocusSite.mismatches} mismatches destabilize R-loop pairing (educational score ${activeFocusSite.score.toFixed(1)}).`;
          }
        } else {
          recMat.color.setHex(0x2ee6c5);
          cutRingMat.opacity = 0;
          if (st.mode === 'hero') {
            nextCaption =
              'Cas9 + guide RNA scanning double-stranded synthetic DNA: checking 3\' PAM motifs and seed complementarity.';
          }
        }

        if (nextCaption !== st.lastCaption) {
          st.lastCaption = nextCaption;
          setCaption(nextCaption);
        }

        // Update base-pair cut separation & gentle helix rotation
        if (!st.reducedMotion) {
          objs.helixRoot.rotation.y += dt * (st.mode === 'hero' ? 0.22 : 0.14);
        }

        const cutBp = activeFocusSite && activeFocusSite.pamOk ? activeFocusSite.cut : -999;
        for (const node of objs.bpNodes) {
          const distFromCut = Math.abs(node.bpIndex1 - cutBp);
          const sep =
            distFromCut <= 4 && st.cutAnim > 0.01
              ? st.cutAnim * (1 - distFromCut / 5) * 0.95
              : 0;
          node.fwdSide.position.x = -sep;
          node.revSide.position.x = sep;
          node.rungMesh.scale.x = Math.max(0.08, 1 - sep * 0.65);
          node.rungMesh.visible = sep < 0.72;
        }

        // Smooth camera follow along helix when active & user isn't orbiting manually
        if (st.cameraFollow && !st.userInteracting && !st.reducedMotion && st.mode === 'simulator') {
          _vA.copy(objs.cas9Group.position);
          objs.helixRoot.localToWorld(_vA);
          controls.target.x = THREE.MathUtils.damp(controls.target.x, _vA.x, 3.5, dt);
          controls.target.y = THREE.MathUtils.damp(controls.target.y, _vA.y, 3.5, dt);
          controls.target.z = THREE.MathUtils.damp(controls.target.z, _vA.z, 3.5, dt);
        }

        // Keep stepY referenced cleanly
        void stepY;
      }

      controls.update();
      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(() => {
          if (!disposed) tick(performance.now());
        });
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    if (isSoftwareGl) {
      frameId = window.setTimeout(() => tick(performance.now()), 16);
    } else {
      frameId = requestAnimationFrame(tick);
    }

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      resizeObs.disconnect();
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      controls.dispose();
      envTex.dispose();
      renderer.dispose();
      sceneObjectsRef.current = null;
    };
  }, [mode]);

  // Rebuild / recolor DNA double helix geometry whenever DNA slice or site highlights change
  useEffect(() => {
    const objs = sceneObjectsRef.current;
    if (!objs) return;

    // Clear previous bpNodes
    for (const node of objs.bpNodes) {
      objs.helixRoot.remove(node.group);
    }
    objs.bpNodes = [];

    const bpCount = visibleDna.length;
    const stepY = 0.56;
    const twistPerBp = (Math.PI * 2) / 10.5;
    const radius = 1.95;
    const halfH = ((bpCount - 1) * stepY) / 2;
    objs.helixStepY = stepY;
    objs.helixHalfHeight = halfH;

    // Shared geometries for high performance
    const backboneGeo = new THREE.SphereGeometry(0.24, 16, 14);
    const baseGeo = new THREE.SphereGeometry(0.32, 18, 16);
    const rungGeo = new THREE.CylinderGeometry(0.085, 0.085, radius * 1.45, 10);
    rungGeo.rotateZ(Math.PI / 2);
    const ringGeo = new THREE.TorusGeometry(2.38, 0.045, 8, 32);
    ringGeo.rotateX(Math.PI / 2);

    const backboneMat = new THREE.MeshPhysicalMaterial({
      color: 0x3b586d,
      roughness: 0.25,
      metalness: 0.45,
      clearcoat: 0.7,
    });

    // Pre-index site annotations per 1-based bp coordinate
    const bpHighlight = new Map<
      number,
      {
        siteCategory?: SiteMatch['category'];
        isPam?: boolean;
        isMismatch?: boolean;
      }
    >();

    for (const s of sites) {
      for (let p = s.pamStart; p <= s.pamEnd; p++) {
        const prev = bpHighlight.get(p) ?? {};
        bpHighlight.set(p, { ...prev, isPam: s.pamOk, siteCategory: prev.siteCategory ?? s.category });
      }
      for (let p = s.start; p <= s.end; p++) {
        const guideIdx1 = s.strand === '+' ? p - s.start + 1 : s.end - p + 1;
        const isMm = s.mismatchPositions.includes(guideIdx1);
        const prev = bpHighlight.get(p) ?? {};
        // Prioritize stronger match category
        const priority = { 'on-target': 4, 'near-match': 3, 'high-mismatch': 2, 'no-pam': 1 };
        const bestCat =
          !prev.siteCategory || priority[s.category] > priority[prev.siteCategory]
            ? s.category
            : prev.siteCategory;
        bpHighlight.set(p, {
          ...prev,
          siteCategory: bestCat,
          isMismatch: prev.isMismatch || isMm,
        });
      }
    }

    // Also draw smooth backbone connecting struts between adjacent bases
    const fwdBackbonePts: THREE.Vector3[] = [];
    const revBackbonePts: THREE.Vector3[] = [];

    for (let i = 0; i < bpCount; i++) {
      const bpIndex1 = sliceStart1 + i;
      const baseFwd = visibleDna[i];
      const baseRev = COMPLEMENT[baseFwd] ?? 'T';
      const y = i * stepY - halfH;
      const angle = i * twistPerBp;

      const x1 = Math.cos(angle) * radius;
      const z1 = Math.sin(angle) * radius;
      const x2 = -x1;
      const z2 = -z1;

      fwdBackbonePts.push(new THREE.Vector3(x1, y, z1));
      revBackbonePts.push(new THREE.Vector3(x2, y, z2));

      const ann = bpHighlight.get(bpIndex1);

      const fwdColor = ann?.isMismatch
        ? CATEGORY_COLORS.mismatchBase
        : ann?.isPam
        ? CATEGORY_COLORS.pam
        : BASE_COLORS[baseFwd] ?? 0x2ee6c5;

      const revColor = ann?.isPam
        ? CATEGORY_COLORS.pam
        : BASE_COLORS[baseRev] ?? 0x4cc9ff;

      const fwdBaseMat = new THREE.MeshPhysicalMaterial({
        color: fwdColor,
        emissive: ann?.isMismatch ? 0xff1e4d : ann?.isPam ? 0x5b35ff : fwdColor,
        emissiveIntensity: ann?.isMismatch ? 0.95 : ann?.isPam ? 0.55 : 0.18,
        roughness: 0.16,
        metalness: 0.1,
        clearcoat: 1.0,
        clearcoatRoughness: 0.08,
      });

      const revBaseMat = new THREE.MeshPhysicalMaterial({
        color: revColor,
        emissive: ann?.isPam ? 0x5b35ff : revColor,
        emissiveIntensity: ann?.isPam ? 0.45 : 0.14,
        roughness: 0.16,
        metalness: 0.1,
        clearcoat: 1.0,
        clearcoatRoughness: 0.08,
      });

      const rungColor = ann?.siteCategory
        ? CATEGORY_COLORS[ann.siteCategory]
        : 0x304a5a;

      const rungMat = new THREE.MeshStandardMaterial({
        color: rungColor,
        emissive: ann?.siteCategory ? rungColor : 0x000000,
        emissiveIntensity: ann?.siteCategory ? 0.35 : 0,
        roughness: 0.35,
        metalness: 0.35,
      });

      const bpGroup = new THREE.Group();
      bpGroup.position.y = y;

      const fwdSide = new THREE.Group();
      const revSide = new THREE.Group();

      const fwdBackboneMesh = new THREE.Mesh(backboneGeo, backboneMat);
      fwdBackboneMesh.position.set(x1, 0, z1);
      fwdSide.add(fwdBackboneMesh);

      const fwdBaseMesh = new THREE.Mesh(baseGeo, fwdBaseMat);
      fwdBaseMesh.position.set(x1 * 0.62, 0, z1 * 0.62);
      fwdSide.add(fwdBaseMesh);

      const revBackboneMesh = new THREE.Mesh(backboneGeo, backboneMat);
      revBackboneMesh.position.set(x2, 0, z2);
      revSide.add(revBackboneMesh);

      const revBaseMesh = new THREE.Mesh(baseGeo, revBaseMat);
      revBaseMesh.position.set(x2 * 0.62, 0, z2 * 0.62);
      revSide.add(revBaseMesh);

      const rungMesh = new THREE.Mesh(rungGeo, rungMat);
      rungMesh.rotation.y = -angle;

      // Subtle site halo ring
      const ringMat = new THREE.MeshBasicMaterial({
        color: ann?.isPam ? CATEGORY_COLORS.pam : CATEGORY_COLORS[ann?.siteCategory ?? 'on-target'],
        transparent: true,
        opacity: ann?.siteCategory ? 0.25 : 0,
      });
      const ringMarker = new THREE.Mesh(ringGeo, ringMat);
      ringMarker.visible = Boolean(ann?.siteCategory);

      bpGroup.add(fwdSide, revSide, rungMesh, ringMarker);
      objs.helixRoot.add(bpGroup);

      objs.bpNodes.push({
        bpIndex1,
        baseFwd,
        baseRev,
        y,
        angle,
        group: bpGroup,
        fwdSide,
        revSide,
        fwdBaseMesh,
        revBaseMesh,
        fwdBackboneMesh,
        revBackboneMesh,
        rungMesh,
        ringMarker,
      });
    }

    // Add continuous sugar-phosphate backbone ribbons
    if (fwdBackbonePts.length > 2) {
      const tubeMat = new THREE.MeshPhysicalMaterial({
        color: 0x4c6e85,
        roughness: 0.28,
        metalness: 0.55,
        clearcoat: 0.6,
      });
      const fwdTube = new THREE.Mesh(
        new THREE.TubeGeometry(new THREE.CatmullRomCurve3(fwdBackbonePts), bpCount * 2, 0.11, 8, false),
        tubeMat
      );
      const revTube = new THREE.Mesh(
        new THREE.TubeGeometry(new THREE.CatmullRomCurve3(revBackbonePts), bpCount * 2, 0.11, 8, false),
        tubeMat
      );
      const ribbonGroup = new THREE.Group();
      ribbonGroup.add(fwdTube, revTube);
      // Attach to first node group so cleanup removes it automatically
      if (objs.bpNodes[0]) {
        // Offset by -objs.bpNodes[0].y since bpGroup is at y
        ribbonGroup.position.y = -objs.bpNodes[0].y;
        objs.bpNodes[0].group.add(ribbonGroup);
      }
    }

    // Keep unused math vectors referenced so TS noUnusedLocals stays happy
    void _vB;
    void _mid;
    void _dir;
    void _up;
    void _quat;
    void _targetCtrl;
  }, [visibleDna, sliceStart1, sites]);

  const handleStepSite = () => {
    if (sites.length === 0) return;
    const nextIdx =
      selectedSiteIndex === null ? 0 : (selectedSiteIndex + 1) % sites.length;
    onSelectSite?.(nextIdx);
  };

  const handleResetCamera = () => {
    simStateRef.current.resetCameraRequested = true;
  };

  if (webglError) {
    return (
      <div
        className={`relative rounded-xl border border-[#1b2b37] bg-[#0e1922] p-6 flex flex-col items-center justify-center text-center gap-3 ${className}`}
      >
        <Sparkles className="w-8 h-8 text-[#2ee6c5]" aria-hidden="true" />
        <h3 className="font-display text-lg font-semibold text-[#e8f3f1]">
          3D WebGL Preview Unavailable
        </h3>
        <p className="text-sm text-[#8aa4ad] max-w-md">{webglError}</p>
      </div>
    );
  }

  return (
    <div
      className={`relative overflow-hidden rounded-xl border border-[#1b2b37] bg-[#070d12] ${className}`}
    >
      {/* Dedicated Empty WebGL Mount Container */}
      <div
        ref={mountRef}
        className="w-full h-full min-h-[340px]"
        aria-label="Interactive 3D CRISPR-Cas9 DNA double helix simulation"
      />

      {/* Top-left compact legend & coordinate indicator (no backdrop-blur over WebGL) */}
      {mode === 'simulator' && (
        <div className="pointer-events-none absolute top-3 left-3 right-3 flex flex-wrap items-center justify-between gap-2 z-10">
          <div
            className="pointer-events-auto px-3 py-1.5 rounded-lg border border-[#1b2b37] text-xs font-mono text-[#e8f3f1] flex items-center gap-3"
            style={{ backgroundColor: 'rgba(14, 25, 34, 0.92)' }}
          >
            <span>Window: {sliceStart1}–{sliceEnd1} bp</span>
            <span className="text-[#8aa4ad]" aria-hidden="true">·</span>
            <span className="text-[#2ee6c5]">Cas9 pos: bp {activeScanBp}</span>
          </div>

          <div
            className="pointer-events-auto hidden sm:flex items-center gap-3 px-3 py-1.5 rounded-lg border border-[#1b2b37] text-xs text-[#c7d8d6]"
            style={{ backgroundColor: 'rgba(14, 25, 34, 0.92)' }}
          >
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-[#3ddc84]" aria-hidden="true" />
              Perfect
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-[#ffb020]" aria-hidden="true" />
              1–2 MM
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-[#ff4d6d]" aria-hidden="true" />
              3+ MM
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-[#64748b]" aria-hidden="true" />
              No PAM
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-[#7c5cff]" aria-hidden="true" />
              PAM
            </span>
          </div>
        </div>
      )}

      {/* Unified Collapsible Bottom Control Dock (only in simulator mode) */}
      {mode === 'simulator' && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 w-[94%] max-w-3xl z-10 flex flex-col items-center">
          <button
            type="button"
            onClick={() => setDockCollapsed((prev) => !prev)}
            className="mb-1.5 px-3 py-1 rounded-t-lg border border-b-0 border-[#1b2b37] text-xs font-medium text-[#8aa4ad] hover:text-[#e8f3f1] flex items-center gap-1.5 cursor-pointer"
            style={{ backgroundColor: 'rgba(14, 25, 34, 0.94)' }}
          >
            {dockCollapsed ? (
              <>
                <ChevronUp className="w-3.5 h-3.5" aria-hidden="true" />
                Show controls
              </>
            ) : (
              <>
                <ChevronDown className="w-3.5 h-3.5" aria-hidden="true" />
                Hide controls
              </>
            )}
          </button>

          {!dockCollapsed && (
            <div
              className="w-full rounded-xl border border-[#1b2b37] px-4 py-3 space-y-2.5"
              style={{ backgroundColor: 'rgba(14, 25, 34, 0.94)' }}
            >
              <p className="text-xs sm:text-sm text-[#e8f3f1] leading-snug">{caption}</p>
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-[#1b2b37]">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsPlaying((p) => !p)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold gw-gradient-btn cursor-pointer whitespace-nowrap"
                  >
                    {isPlaying ? (
                      <>
                        <Pause className="w-3.5 h-3.5" aria-hidden="true" />
                        Pause simulation
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5" aria-hidden="true" />
                        Play simulation
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={handleStepSite}
                    disabled={sites.length === 0}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-[#1b2b37] bg-[#070d12] text-[#e8f3f1] hover:border-[#2ee6c5]/50 disabled:opacity-40 cursor-pointer whitespace-nowrap"
                  >
                    <SkipForward className="w-3.5 h-3.5" aria-hidden="true" />
                    Next site
                  </button>

                  <button
                    type="button"
                    onClick={handleResetCamera}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-[#1b2b37] bg-[#070d12] text-[#e8f3f1] hover:border-[#2ee6c5]/50 cursor-pointer whitespace-nowrap"
                  >
                    <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                    Reset view
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex items-center rounded-lg border border-[#1b2b37] bg-[#070d12] p-0.5 text-xs">
                    {[0.5, 1, 2].map((spd) => (
                      <button
                        key={spd}
                        type="button"
                        onClick={() => setSpeedMultiplier(spd)}
                        className={`px-2 py-1 rounded-md font-mono cursor-pointer ${
                          speedMultiplier === spd
                            ? 'bg-[#1b2b37] text-[#2ee6c5]'
                            : 'text-[#8aa4ad] hover:text-[#e8f3f1]'
                        }`}
                      >
                        {spd}x
                      </button>
                    ))}
                  </div>

                  <button
                    type="button"
                    onClick={toggleReducedMotion}
                    aria-pressed={reducedMotion}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border cursor-pointer whitespace-nowrap ${
                      reducedMotion
                        ? 'border-[#2ee6c5] bg-[#2ee6c5]/15 text-[#2ee6c5]'
                        : 'border-[#1b2b37] bg-[#070d12] text-[#8aa4ad] hover:text-[#e8f3f1]'
                    }`}
                  >
                    <Eye className="w-3.5 h-3.5" aria-hidden="true" />
                    Reduced motion
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
