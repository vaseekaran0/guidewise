import React, { useEffect, useState } from 'react';
import { AlertCircle, ArrowUpRight, GitCompare, Plus, Trash2 } from 'lucide-react';
import { SUPPORTED_PAMS, TEST_VECTOR } from '../shared/crisprEngine.js';
import { AnalyzeApiResponse, GuideAnalysisResult, PamType } from '../types/crispr.js';

interface ComparePageProps {
  initialCompare?: {
    dna: string;
    guides: string[];
    pam: PamType;
    maxMm: number;
  } | null;
  onLoadInSimulator: (dna: string, guide: string, pam: PamType, maxMm: number) => void;
}

const DEFAULT_COMPARE_GUIDES = [
  TEST_VECTOR.guide, // 14-33 perfect + 47-66 off-target
  'TGGCCATTAGCATGATGCGT', // shifts toward middle region
  'GATCCGTAACGGTTCATCTA', // matches 47-66 closely
];

export const ComparePage: React.FC<ComparePageProps> = ({ initialCompare, onLoadInSimulator }) => {
  const [dna, setDna] = useState<string>(initialCompare?.dna || TEST_VECTOR.dna);
  const [guides, setGuides] = useState<string[]>(
    initialCompare?.guides?.length ? initialCompare.guides : DEFAULT_COMPARE_GUIDES
  );
  const [pam, setPam] = useState<PamType>(initialCompare?.pam || 'NGG');
  const [maxMm, setMaxMm] = useState<number>(initialCompare?.maxMm ?? 4);

  const [result, setResult] = useState<AnalyzeApiResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const runComparison = async (
    targetDna: string,
    guideList: string[],
    targetPam: PamType,
    targetMaxMm: number
  ) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dna: targetDna,
          guides: guideList,
          pam: targetPam,
          max_mm: targetMaxMm,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Comparison failed validation.');
        setResult(null);
        return;
      }
      setResult(data as AnalyzeApiResponse);
    } catch {
      setError('Unable to reach GuideWise comparison server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    runComparison(dna, guides, pam, maxMm);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleAddGuide = () => {
    if (guides.length >= 6) return;
    setGuides((prev) => [...prev, '']);
  };

  const handleRemoveGuide = (idx: number) => {
    if (guides.length <= 2) return;
    setGuides((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleGuideChange = (idx: number, val: string) => {
    setGuides((prev) => prev.map((g, i) => (i === idx ? val : g)));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    runComparison(dna, guides, pam, maxMm);
  };

  // Rank guides by best score descending, then fewest off-target valid PAM hits
  const rankedResults: Array<GuideAnalysisResult & { offTargetValid: number }> = result
    ? [...result.resultsByGuide]
        .map((gr) => {
          const offTargetValid = gr.sites.filter((s) => s.pamOk && s.mismatches > 0).length;
          return { ...gr, offTargetValid };
        })
        .sort((a, b) => {
          if (b.summary.bestScore !== a.summary.bestScore) {
            return b.summary.bestScore - a.summary.bestScore;
          }
          return a.offTargetValid - b.offTargetValid;
        })
    : [];

  return (
    <div className="max-w-[1440px] w-full mx-auto px-4 sm:px-6 py-8 space-y-6">
      <div className="border-b border-[#1b2b37] pb-5 space-y-1">
        <h1 className="font-display text-2xl sm:text-3xl font-semibold text-[#e8f3f1]">
          Multi-Guide Comparison
        </h1>
        <p className="text-sm text-[#8aa4ad]">
          Evaluate 2 to 6 candidate guide RNAs side by side against the same synthetic DNA sequence and visualize overlapping target sites on a single map.
        </p>
      </div>

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="gw-panel p-5 sm:p-6 space-y-5">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 space-y-3">
            <label htmlFor="compare-dna" className="block text-xs font-medium text-[#e8f3f1]">
              Shared synthetic DNA sequence (FASTA or plain, ≥30 bp)
            </label>
            <textarea
              id="compare-dna"
              rows={5}
              value={dna}
              onChange={(e) => setDna(e.target.value)}
              spellCheck={false}
              className="w-full rounded-lg border border-[#1b2b37] bg-[#070d12] px-3 py-2.5 text-xs font-mono text-[#e8f3f1] focus:border-[#2ee6c5] focus:outline-none"
            />
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="compare-pam" className="block text-xs font-medium text-[#e8f3f1] mb-1">
                  PAM motif
                </label>
                <select
                  id="compare-pam"
                  value={pam}
                  onChange={(e) => setPam(e.target.value as PamType)}
                  className="w-full rounded-lg border border-[#1b2b37] bg-[#070d12] px-3 py-2 text-xs font-mono text-[#e8f3f1]"
                >
                  {(Object.keys(SUPPORTED_PAMS) as PamType[]).map((k) => (
                    <option key={k} value={k}>
                      {k}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="compare-mm" className="block text-xs font-medium text-[#e8f3f1] mb-1">
                  Max mismatches: <span className="font-mono text-[#2ee6c5]">{maxMm}</span>
                </label>
                <input
                  id="compare-mm"
                  type="range"
                  min={0}
                  max={6}
                  value={maxMm}
                  onChange={(e) => setMaxMm(Number(e.target.value))}
                  className="w-full accent-[#2ee6c5] mt-2 cursor-pointer"
                />
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-[#e8f3f1]">
                Candidate guide RNAs (15–25 bases each)
              </span>
              <button
                type="button"
                onClick={handleAddGuide}
                disabled={guides.length >= 6}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-[#1b2b37] bg-[#070d12] text-xs text-[#2ee6c5] hover:border-[#2ee6c5]/50 disabled:opacity-40 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                Add guide ({guides.length}/6)
              </button>
            </div>

            <div className="space-y-2">
              {guides.map((g, idx) => (
                <div key={`guide-row-${idx}`} className="flex items-center gap-2">
                  <span className="w-16 text-xs font-mono text-[#8aa4ad] shrink-0">
                    Guide #{idx + 1}
                  </span>
                  <input
                    type="text"
                    value={g}
                    onChange={(e) => handleGuideChange(idx, e.target.value)}
                    spellCheck={false}
                    placeholder="Enter 15-25 nt guide sequence..."
                    className="flex-1 rounded-lg border border-[#1b2b37] bg-[#070d12] px-3 py-2 text-xs font-mono text-[#e8f3f1] focus:border-[#2ee6c5] focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => handleRemoveGuide(idx)}
                    disabled={guides.length <= 2}
                    aria-label={`Remove guide ${idx + 1}`}
                    className="p-2 rounded-lg border border-[#1b2b37] text-[#8aa4ad] hover:text-[#ff4d6d] disabled:opacity-30 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" aria-hidden="true" />
                  </button>
                </div>
              ))}
            </div>

            <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
              {error ? (
                <div className="flex items-center gap-2 text-xs text-[#ff4d6d]">
                  <AlertCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>{error}</span>
                </div>
              ) : (
                <span className="text-xs text-[#8aa4ad]">
                  Scores are educational estimates comparing seed complementarity and PAM validity.
                </span>
              )}

              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold gw-gradient-btn cursor-pointer whitespace-nowrap"
              >
                <GitCompare className="w-4 h-4" aria-hidden="true" />
                {loading ? 'Comparing guides...' : 'Compare guides'}
              </button>
            </div>
          </div>
        </div>
      </form>

      {/* Ranking Table */}
      {result && (
        <section className="gw-panel overflow-hidden">
          <div className="px-5 py-4 border-b border-[#1b2b37] flex flex-wrap items-center justify-between gap-2">
            <h2 className="font-display text-lg font-semibold text-[#e8f3f1]">
              Guide Ranking Table (Educational Estimate)
            </h2>
            <span className="text-xs font-mono text-[#8aa4ad]">
              Saved as Run #{result.runId} · DNA {result.dna.length} bp · PAM {result.pam}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-[#1b2b37] bg-[#070d12] text-xs text-[#8aa4ad]">
                  <th className="py-3 px-4">Rank</th>
                  <th className="py-3 px-4">Guide Sequence (5&apos;→3&apos;)</th>
                  <th className="py-3 px-4">Best Score (Ed. Est.)</th>
                  <th className="py-3 px-4">Perfect (0 MM)</th>
                  <th className="py-3 px-4">Valid PAM Off-Targets</th>
                  <th className="py-3 px-4">No-PAM Sites</th>
                  <th className="py-3 px-4 text-right">Inspect</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1b2b37]">
                {rankedResults.map((gr, rankIdx) => {
                  const noPamCount = gr.sites.filter((s) => !s.pamOk).length;
                  return (
                    <tr key={gr.guide + rankIdx} className="hover:bg-[#070d12]/60">
                      <td className="py-3 px-4 font-mono text-xs text-[#2ee6c5] font-semibold">
                        #{rankIdx + 1}
                      </td>
                      <td className="py-3 px-4 font-mono text-xs text-[#e8f3f1]">{gr.guide}</td>
                      <td className="py-3 px-4 font-mono text-sm font-semibold tabular-nums text-[#3ddc84]">
                        {gr.summary.bestScore.toFixed(1)}
                      </td>
                      <td className="py-3 px-4 font-mono text-xs tabular-nums text-[#e8f3f1]">
                        {gr.summary.perfectMatches}
                      </td>
                      <td className="py-3 px-4 font-mono text-xs tabular-nums text-[#ffb020]">
                        {gr.offTargetValid}
                      </td>
                      <td className="py-3 px-4 font-mono text-xs tabular-nums text-[#8aa4ad]">
                        {noPamCount}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => onLoadInSimulator(result.dna, gr.guide, result.pam, result.max_mm)}
                          className="inline-flex items-center gap-1 text-xs font-medium text-[#2ee6c5] hover:underline cursor-pointer"
                        >
                          Open in 3D
                          <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* Visual Comparison Map on One Coordinate Ruler */}
      {result && (
        <section className="gw-panel p-5 sm:p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-lg font-semibold text-[#e8f3f1]">
                Unified Target Site Map
              </h2>
              <p className="text-xs text-[#8aa4ad]">
                All candidate sites plotted across 1–{result.dna.length} bp (top bar = + strand, bottom bar = - strand per guide).
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-4 text-xs text-[#c7d8d6]">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-[#3ddc84]" aria-hidden="true" />
                0 MM (Valid PAM)
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-[#ffb020]" aria-hidden="true" />
                1–2 MM
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-[#ff4d6d]" aria-hidden="true" />
                3+ MM
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-[#64748b]" aria-hidden="true" />
                No PAM (0.0)
              </span>
            </div>
          </div>

          <div className="space-y-3 rounded-lg border border-[#1b2b37] bg-[#070d12] p-4">
            {rankedResults.map((gr, idx) => (
              <div key={`lane-${idx}`} className="space-y-1.5 pb-2 border-b border-[#1b2b37]/60 last:border-b-0 last:pb-0">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-[#e8f3f1]">
                    #{idx + 1} · {gr.guide}
                  </span>
                  <span className="text-[#8aa4ad]">
                    {gr.sites.length} candidate(s) · Best {gr.summary.bestScore.toFixed(1)}
                  </span>
                </div>
                <div className="relative h-9 rounded bg-[#0e1922] border border-[#1b2b37] overflow-hidden">
                  {/* Center hairline dividing + and - strands */}
                  <div className="absolute left-0 right-0 top-1/2 h-px bg-[#1b2b37]" aria-hidden="true" />
                  {gr.sites.map((s, sIdx) => {
                    const leftPct = ((s.start - 1) / result.dna.length) * 100;
                    const widthPct = Math.max(1.8, ((s.end - s.start + 1) / result.dna.length) * 100);
                    const bg = !s.pamOk
                      ? 'bg-[#64748b]'
                      : s.mismatches === 0
                      ? 'bg-[#3ddc84]'
                      : s.mismatches <= 2
                      ? 'bg-[#ffb020]'
                      : 'bg-[#ff4d6d]';
                    return (
                      <div
                        key={`hit-${idx}-${sIdx}`}
                        style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                        title={`${s.strand} ${s.start}-${s.end} | ${s.mismatches} MM | PAM ${s.pam} | Score ${s.score.toFixed(1)}`}
                        className={`absolute ${
                          s.strand === '+' ? 'top-0.5 bottom-[52%]' : 'top-[52%] bottom-0.5'
                        } rounded-sm ${bg} text-[9px] font-mono font-bold text-[#070d12] flex items-center justify-center`}
                      >
                        {s.score.toFixed(0)}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}

            <div className="flex justify-between text-[11px] font-mono text-[#8aa4ad] pt-1">
              <span>1 bp</span>
              <span>{Math.round(result.dna.length * 0.25)} bp</span>
              <span>{Math.round(result.dna.length * 0.5)} bp</span>
              <span>{Math.round(result.dna.length * 0.75)} bp</span>
              <span>{result.dna.length} bp</span>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
