import React, { useMemo, useState } from 'react';
import { BookOpen, MessageSquare, Search, Send, ShieldAlert } from 'lucide-react';
import { EDUCATIONAL_DISCLAIMER } from '../shared/crisprEngine.js';
import { CRISPR_KNOWLEDGE_BASE } from '../shared/knowledgeBase.js';
import { AnalyzeApiResponse, ChatMessage } from '../types/crispr.js';

interface LearnPageProps {
  latestRun: AnalyzeApiResponse | null;
}

const CORE_CONCEPTS = [
  {
    id: 'dna',
    term: 'DNA',
    title: 'Double-stranded genetic blueprint',
    summary:
      'DNA consists of two antiparallel strands built from Adenine (A), Thymine (T), Guanine (G), and Cytosine (C). A pairs with T and G pairs with C across the helix.',
    visual: '5\' A-T-G-C-C-A 3\'  ↔  3\' T-A-C-G-G-T 5\'',
  },
  {
    id: 'grna',
    term: 'Guide RNA',
    title: 'Programmable 15–25 nt address',
    summary:
      'The guide RNA spacer sequence directs Cas9 to a matching DNA target. In RNA, Uracil (U) takes the place of Thymine (T) and pairs identically with Adenine (A).',
    visual: '5\' GAUCCGUAACGGUUCAGCUA 3\'  (U → T when matching)',
  },
  {
    id: 'cas9',
    term: 'Cas9',
    title: 'RNA-guided molecular nuclease',
    summary:
      'Cas9 is a protein complex that carries the guide RNA, scans DNA duplexes for PAM motifs, melts the double helix locally, and cuts both DNA strands if pairing succeeds.',
    visual: 'Cas9 + Guide RNA = Ribonucleoprotein scanning complex',
  },
  {
    id: 'pam',
    term: 'PAM',
    title: 'Protospacer Adjacent Motif (3′ anchor)',
    summary:
      'A short sequence (e.g. NGG for SpCas9, NAG alternate, NNGRRT for SaCas9) sitting immediately 3′ of the target. Without a valid PAM, Cas9 will not bind or cleave (score 0.0).',
    visual: '[ 20-bp Target Window ] + [ 3′ PAM: NGG ]',
  },
  {
    id: 'mismatch',
    term: 'Mismatch',
    title: 'Base differences (Hamming distance)',
    summary:
      'A mismatch occurs where the guide RNA letter differs from the target DNA letter. Fewer mismatches generally yield stronger binding.',
    visual: 'Guide: G A T C ... vs Target: G A T G ...  →  Mismatch at pos 4',
  },
  {
    id: 'seed',
    term: 'Seed Region',
    title: 'Last 10 bases proximal to the PAM',
    summary:
      'Cas9 initiates RNA–DNA pairing adjacent to the PAM and zippers outward. Mismatches inside these last 10 seed bases destabilize binding far more (penalty 3 vs 1).',
    visual: '[ Upstream 1–10: penalty 1 ] [ Seed 11–20: penalty 3 ] [ PAM ]',
  },
  {
    id: 'off-target',
    term: 'Off-Target',
    title: 'Unintended near-matching sites',
    summary:
      'Sequences elsewhere in DNA that share a valid PAM and differ by only a few bases can still bind Cas9 weakly. Educational scores estimate this relative similarity.',
    visual: '2 mismatches (pos 4 & 17) + PAM AGG → Score 13.5 (Ed. Estimate)',
  },
  {
    id: 'cut-site',
    term: 'Cut Site',
    title: 'Double-strand break 3 bp before PAM',
    summary:
      'Cas9 cleaves both DNA strands 3 base pairs upstream of the PAM inside the protospacer. Repair can produce small insertions or deletions (illustrated as 1-bp indels).',
    visual: '14..30 | 31-32-33 [TGG PAM]  →  Cut after base 30',
  },
];

const SUGGESTED_QUESTIONS = [
  'Why does site 80-99 score 0.0 even though it has 0 mismatches?',
  'How does the seed region affect the educational estimate score?',
  'Where does Cas9 cut relative to the PAM on forward and reverse strands?',
  'Can you give me a wet-lab protocol to edit BRCA1 in human cells?',
];

export const LearnPage: React.FC<LearnPageProps> = ({ latestRun }) => {
  const [selectedConceptId, setSelectedConceptId] = useState<string>('dna');
  const [glossaryQuery, setGlossaryQuery] = useState<string>('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: `Ask any conceptual question about DNA, guide RNA, PAM motifs, mismatch scoring, or your current simulation run. Answers are strictly grounded in the GuideWise educational knowledge base.\n\n${EDUCATIONAL_DISCLAIMER}`,
      mode: 'kb-deterministic',
      sources: ['GuideWise Knowledge Base (32 entries)'],
      timestamp: new Date().toISOString(),
    },
  ]);
  const [questionInput, setQuestionInput] = useState<string>('');
  const [asking, setAsking] = useState<boolean>(false);

  const selectedConcept =
    CORE_CONCEPTS.find((c) => c.id === selectedConceptId) ?? CORE_CONCEPTS[0];

  const filteredGlossary = useMemo(() => {
    const q = glossaryQuery.trim().toLowerCase();
    if (!q) return CRISPR_KNOWLEDGE_BASE;
    return CRISPR_KNOWLEDGE_BASE.filter(
      (item) =>
        item.topic.toLowerCase().includes(q) ||
        item.question.toLowerCase().includes(q) ||
        item.answer.toLowerCase().includes(q)
    );
  }, [glossaryQuery]);

  const sendQuestion = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || asking) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      content: trimmed,
      timestamp: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, userMsg]);
    setQuestionInput('');
    setAsking(true);

    try {
      const runContext = latestRun
        ? {
            dnaLength: latestRun.dna.length,
            pam: latestRun.pam,
            maxMm: latestRun.max_mm,
            guide: latestRun.guide,
            totalSites: latestRun.sites.length,
            bestScore: latestRun.summary.bestScore,
          }
        : undefined;

      const res = await fetch('/api/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: trimmed, runContext }),
      });
      const data = await res.json();
      const assistantMsg: ChatMessage = {
        id: `a-${Date.now()}`,
        role: 'assistant',
        content: res.ok
          ? data.answer
          : `${data.error || 'Unable to answer right now.'}\n\n${EDUCATIONAL_DISCLAIMER}`,
        mode: data.mode,
        sources: data.sources,
        timestamp: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'assistant',
          content: `Local server connection unavailable.\n\n${EDUCATIONAL_DISCLAIMER}`,
          timestamp: new Date().toISOString(),
        },
      ]);
    } finally {
      setAsking(false);
    }
  };

  const handleAskSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendQuestion(questionInput);
  };

  return (
    <div className="max-w-[1440px] w-full mx-auto px-4 sm:px-6 py-8 space-y-10">
      <div className="border-b border-[#1b2b37] pb-5 space-y-1">
        <h1 className="font-display text-2xl sm:text-3xl font-semibold text-[#e8f3f1]">
          Learn CRISPR Concepts &amp; Grounded Q&amp;A
        </h1>
        <p className="text-sm text-[#8aa4ad]">
          Step-by-step beginner explanations, a searchable 32-entry glossary, and a grounded assistant that refuses wet-lab or real-pathogen queries.
        </p>
      </div>

      {/* 8 Beginner Core Concepts Explorer */}
      <section className="space-y-4">
        <h2 className="font-display text-xl font-semibold text-[#e8f3f1]">
          Core Concepts Explorer
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-2 gap-2.5">
            {CORE_CONCEPTS.map((c) => {
              const active = c.id === selectedConcept.id;
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setSelectedConceptId(c.id)}
                  className={`text-left px-4 py-3 rounded-xl border transition-colors cursor-pointer ${
                    active
                      ? 'border-[#2ee6c5] bg-[#2ee6c5]/10 text-[#e8f3f1]'
                      : 'border-[#1b2b37] bg-[#0e1922] text-[#8aa4ad] hover:text-[#e8f3f1]'
                  }`}
                >
                  <div className="font-display text-sm font-semibold text-[#e8f3f1]">{c.term}</div>
                  <div className="text-xs text-[#8aa4ad] truncate mt-0.5">{c.title}</div>
                </button>
              );
            })}
          </div>

          <div className="lg:col-span-7 gw-panel p-6 flex flex-col justify-between gap-5">
            <div className="space-y-3">
              <div className="text-xs font-mono text-[#2ee6c5]">Concept · {selectedConcept.term}</div>
              <h3 className="font-display text-2xl font-semibold text-[#e8f3f1]">
                {selectedConcept.title}
              </h3>
              <p className="text-sm sm:text-base text-[#c7d8d6] leading-relaxed">
                {selectedConcept.summary}
              </p>
            </div>
            <div className="rounded-lg border border-[#1b2b37] bg-[#070d12] px-4 py-3 font-mono text-xs sm:text-sm text-[#2ee6c5] overflow-x-auto">
              {selectedConcept.visual}
            </div>
          </div>
        </div>
      </section>

      {/* Split Lower Section: Grounded Q&A Assistant (Left) + Glossary (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Grounded Q&A Assistant */}
        <section className="lg:col-span-7 gw-panel p-5 sm:p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#1b2b37] pb-3">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-[#2ee6c5]" aria-hidden="true" />
              <h2 className="font-display text-lg font-semibold text-[#e8f3f1]">
                Grounded Educational Assistant
              </h2>
            </div>
            <span className="text-xs font-mono text-[#8aa4ad]">
              Curated KB · Offline fallback ready
            </span>
          </div>

          {/* Starter Prompts */}
          <div className="flex flex-wrap gap-2">
            {SUGGESTED_QUESTIONS.map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => sendQuestion(q)}
                className="text-left text-xs px-3 py-1.5 rounded-lg border border-[#1b2b37] bg-[#070d12] text-[#c7d8d6] hover:border-[#2ee6c5]/50 hover:text-[#e8f3f1] cursor-pointer"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Chat Transcript */}
          <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`rounded-xl border p-4 space-y-2 text-sm ${
                  m.role === 'user'
                    ? 'border-[#2ee6c5]/40 bg-[#070d12] ml-6'
                    : m.mode === 'safety-refusal'
                    ? 'border-[#ffb020]/50 bg-[#ffb020]/10 mr-4'
                    : 'border-[#1b2b37] bg-[#070d12] mr-4'
                }`}
              >
                <div className="flex items-center justify-between text-xs text-[#8aa4ad]">
                  <span className="font-semibold text-[#e8f3f1]">
                    {m.role === 'user' ? 'Student' : 'GuideWise Assistant'}
                  </span>
                  {m.mode && (
                    <span className="font-mono">
                      {m.mode === 'safety-refusal'
                        ? 'Safety boundary'
                        : m.mode === 'kb-gemini'
                        ? 'KB + Grounded LLM'
                        : 'Knowledge Base'}
                    </span>
                  )}
                </div>
                <div className="text-[#c7d8d6] whitespace-pre-line leading-relaxed text-xs sm:text-sm">
                  {m.content}
                </div>
                {m.sources && m.sources.length > 0 && (
                  <div className="pt-1 border-t border-[#1b2b37]/70 text-[11px] font-mono text-[#8aa4ad]">
                    Grounded in: {m.sources.join(' · ')}
                  </div>
                )}
              </div>
            ))}
            {asking && (
              <div className="text-xs font-mono text-[#2ee6c5] px-2">
                Searching knowledge base...
              </div>
            )}
          </div>

          {/* Ask Input */}
          <form onSubmit={handleAskSubmit} className="flex gap-2 pt-2 border-t border-[#1b2b37]">
            <input
              type="text"
              value={questionInput}
              onChange={(e) => setQuestionInput(e.target.value)}
              placeholder="Ask about PAMs, seed penalty, cut sites, or your run..."
              className="flex-1 rounded-lg border border-[#1b2b37] bg-[#070d12] px-3.5 py-2.5 text-sm text-[#e8f3f1] placeholder-[#8aa4ad]/60 focus:border-[#2ee6c5] focus:outline-none"
            />
            <button
              type="submit"
              disabled={asking || questionInput.trim().length < 2}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-sm font-semibold gw-gradient-btn disabled:opacity-40 cursor-pointer whitespace-nowrap"
            >
              <Send className="w-4 h-4" aria-hidden="true" />
              Ask
            </button>
          </form>

          <div className="flex items-center gap-2 text-[11px] text-[#8aa4ad]">
            <ShieldAlert className="w-3.5 h-3.5 text-[#ffb020] shrink-0" aria-hidden="true" />
            <span>
              Requests for wet-lab protocols, delivery vectors, or real human/pathogen guide design are refused automatically.
            </span>
          </div>
        </section>

        {/* Searchable Knowledge Glossary */}
        <section className="lg:col-span-5 gw-panel p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between gap-2 border-b border-[#1b2b37] pb-3">
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#7c5cff]" aria-hidden="true" />
              <h2 className="font-display text-lg font-semibold text-[#e8f3f1]">
                Educational Glossary ({filteredGlossary.length})
              </h2>
            </div>
          </div>

          <div className="relative">
            <Search
              className="w-4 h-4 text-[#8aa4ad] absolute left-3 top-1/2 -translate-y-1/2"
              aria-hidden="true"
            />
            <input
              type="search"
              value={glossaryQuery}
              onChange={(e) => setGlossaryQuery(e.target.value)}
              placeholder="Filter glossary topics (e.g. PAM, seed, FASTA)..."
              className="w-full rounded-lg border border-[#1b2b37] bg-[#070d12] pl-9 pr-3 py-2 text-xs text-[#e8f3f1] placeholder-[#8aa4ad]/60 focus:border-[#2ee6c5] focus:outline-none"
            />
          </div>

          <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
            {filteredGlossary.map((entry) => (
              <div
                key={entry.id}
                className="rounded-lg border border-[#1b2b37] bg-[#070d12] p-3.5 space-y-1.5"
              >
                <div className="text-[11px] font-mono text-[#2ee6c5]">{entry.topic}</div>
                <h3 className="text-sm font-semibold text-[#e8f3f1]">{entry.question}</h3>
                <p className="text-xs text-[#c7d8d6] leading-relaxed">{entry.answer}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
