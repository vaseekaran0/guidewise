import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Download,
  FlaskConical,
  GitCompare,
  Play,
  SlidersHorizontal,
} from 'lucide-react';
import { DnaHelixViewport } from '../components/DnaHelixViewport.js';
import { HypotheticalEditPanel } from '../components/HypotheticalEditPanel.js';
import { SequenceAlignmentView } from '../components/SequenceAlignmentView.js';
import { SUPPORTED_PAMS, TEST_VECTOR } from '../shared/crisprEngine.js';
import { AnalyzeApiResponse, AppPage, ExampleItem, PamType, SiteMatch } from '../types/crispr.js';

interface SimulatorPageProps {
  initialState?: {
    dna?: string;
    guide?: string;
    pam?: PamType;
    maxMm?: number;
    autoPlay?: boolean;
  } | null;
  onAnalysisComplete?: (result: AnalyzeApiResponse) => void;
  onSendToCompare?: (dna: string, guide: string, pam: PamType, maxMm: number) => void;
  onNavigate: (page: AppPage) => void;
}

export const SimulatorPage: React.FC<SimulatorPageProps> = ({
  initialState,
  onAnalysisComplete,
  onSendToCompare,
}) => {
  const [dnaInput, setDnaInput] = useState<string>(initialState?.dna || TEST_VECTOR.dna);
  const [guideInput, setGuideInput] = useState<string>(initialState?.guide || TEST_VECTOR.guide);
  const [pam, setPam] = useState<PamType>(initialState?.pam || TEST_VECTOR.pam);
  const [maxMm, setMaxMm] = useState<number>(initialState?.maxMm ?? TEST_VECTOR.maxMm);

  const [examples, setExamples] = useState<ExampleItem[]>([]);
  const [analysis, setAnalysis] = useState<AnalyzeApiResponse | null>(null);
  const [selectedSiteIdx, setSelectedSiteIdx] = useState<number | null>(0);
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [autoPlay3D, setAutoPlay3D] = useState<boolean>(Boolean(initialState?.autoPlay));

  useEffect(() => {
    fetch('/api/examples')
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data.examples)) setExamples(data.examples);
      })
      .catch(() => {
        // Non-fatal if offline before first load
      });
  }, []);

  const runAnalysis = async (
    targetDna: string,
    targetGuide: string,
    targetPam: PamType,
    targetMaxMm: number
  ) => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dna: targetDna,
          guide: targetGuide,
          pam: targetPam,
          max_mm: targetMaxMm,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || 'Validation failed.');
        setAnalysis(null);
        setSelectedSiteIdx(null);
        return;
      }
      const typed = data as AnalyzeApiResponse;
      setAnalysis(typed);
      setSelectedSiteIdx(typed.sites.length > 0 ? 0 : null);
      onAnalysisComplete?.(typed);
    } catch {
      setErrorMsg('Unable to reach the local GuideWise simulation server.');
    } finally {
      setLoading(false);
    }
  };

  // Sync incoming initial state (e.g. from "Watch demo" or reloading a saved run)
  useEffect(() => {
    const nextDna = initialState?.dna || TEST_VECTOR.dna;
    const nextGuide = initialState?.guide || TEST_VECTOR.guide;
    const nextPam = initialState?.pam || TEST_VECTOR.pam;
    const nextMaxMm = initialState?.maxMm ?? TEST_VECTOR.maxMm;
    setDnaInput(nextDna);
    setGuideInput(nextGuide);
    setPam(nextPam);
    setMaxMm(nextMaxMm);
    setAutoPlay3D(Boolean(initialState?.autoPlay));
    runAnalysis(nextDna, nextGuide, nextPam, nextMaxMm);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialState]);

  const handleLoadExample = (ex: ExampleItem) => {
    setDnaInput(ex.dna);
    setGuideInput(ex.guide);
    setPam(ex.pam);
    setMaxMm(ex.max_mm);
    runAnalysis(ex.dna, ex.guide, ex.pam, ex.max_mm);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    runAnalysis(dnaInput, guideInput, pam, maxMm);
  };

  const selectedSite: SiteMatch | null =
    analysis && selectedSiteIdx !== null ? analysis.sites[selectedSiteIdx] ?? null : null;

  return (
    <div className="max-w-[1440px] w-full mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Page Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[#1b2b37] pb-5">
        <div className="space-y-1">
          <h1 className="font-display text-2xl sm:text-3xl font-semibold text-[#e8f3f1]">
            CRISPR-Cas9 Target Simulator
          </h1>
          <p className="text-sm text-[#8aa4ad]">
            Paste synthetic DNA (FASTA or plain A/C/G/T/U), choose a PAM motif, and inspect strand matches, educational scores, and 3D cleavage.
          </p>
        </div>

        {analysis && (
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => onSendToCompare?.(analysis.dna, analysis.guide, analysis.pam, analysis.max_mm)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium border border-[#1b2b37] bg-[#0e1922] text-[#e8f3f1] hover:border-[#2ee6c5]/50 cursor-pointer whitespace-nowrap"
            >
              <GitCompare className="w-3.5 h-3.5 text-[#2ee6c5]" aria-hidden="true" />
              Compare multiple guides
            </button>
            <a
              href={`/api/report/${analysis.runId}.pdf`}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium border border-[#1b2b37] bg-[#0e1922] text-[#e8f3f1] hover:border-[#2ee6c5]/50 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5 text-[#2ee6c5]" aria-hidden="true" />
              PDF Report
            </a>
            <a
              href={`/api/report/${analysis.runId}.csv`}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium border border-[#1b2b37] bg-[#0e1922] text-[#e8f3f1] hover:border-[#2ee6c5]/50 whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5 text-[#7c5cff]" aria-hidden="true" />
              CSV
            </a>
          </div>
        )}
      </div>

      {/* Asymmetric Split Console: Inputs Left (360px-400px), 3D Viewer Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left Control & Input Column */}
        <form onSubmit={handleSubmit} className="lg:col-span-4 gw-panel p-5 space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            {/* Built-in Demo Examples */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-[#c7d8d6] flex items-center gap-1.5">
                  <FlaskConical className="w-3.5 h-3.5 text-[#2ee6c5]" aria-hidden="true" />
                  Built-in synthetic demos
                </label>
                <span className="text-[11px] text-[#8aa4ad]">Click to load</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-1.5">
                {examples.map((ex) => (
                  <button
                    key={ex.id}
                    type="button"
                    onClick={() => handleLoadExample(ex)}
                    title={ex.notes}
                    className="text-left px-3 py-2 rounded-lg border border-[#1b2b37] bg-[#070d12] hover:border-[#2ee6c5]/50 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center justify-between gap-2 text-xs font-medium text-[#e8f3f1]">
                      <span className="truncate">{ex.name}</span>
                      <span
                        className={`shrink-0 font-mono text-[11px] ${
                          ex.type === 'positive'
                            ? 'text-[#3ddc84]'
                            : ex.type === 'negative'
                            ? 'text-[#ffb020]'
                            : 'text-[#ff4d6d]'
                        }`}
                      >
                        {ex.type === 'positive' ? 'Pos' : ex.type === 'negative' ? 'Neg' : 'Invalid'}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Synthetic DNA Input */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <label htmlFor="dna-input" className="font-medium text-[#e8f3f1]">
                  Synthetic DNA sequence (5&apos; → 3&apos;)
                </label>
                <span className="font-mono text-[#8aa4ad]">FASTA or plain · ≥30 bp</span>
              </div>
              <textarea
                id="dna-input"
                rows={4}
                value={dnaInput}
                onChange={(e) => setDnaInput(e.target.value)}
                spellCheck={false}
                placeholder="Paste synthetic A/C/G/T sequence or FASTA..."
                className="w-full rounded-lg border border-[#1b2b37] bg-[#070d12] px-3 py-2.5 text-xs font-mono text-[#e8f3f1] placeholder-[#8aa4ad]/60 focus:border-[#2ee6c5] focus:outline-none"
              />
            </div>

            {/* Guide RNA Input */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <label htmlFor="guide-input" className="font-medium text-[#e8f3f1]">
                  Guide RNA spacer (5&apos; → 3&apos;)
                </label>
                <span className="font-mono text-[#8aa4ad]">15–25 bases (U → T)</span>
              </div>
              <input
                id="guide-input"
                type="text"
                value={guideInput}
                onChange={(e) => setGuideInput(e.target.value)}
                spellCheck={false}
                placeholder="e.g. GATCCGTAACGGTTCAGCTA"
                className="w-full rounded-lg border border-[#1b2b37] bg-[#070d12] px-3 py-2.5 text-xs font-mono text-[#e8f3f1] placeholder-[#8aa4ad]/60 focus:border-[#2ee6c5] focus:outline-none"
              />
            </div>

            {/* PAM Selector */}
            <div className="space-y-1.5">
              <label htmlFor="pam-select" className="block text-xs font-medium text-[#e8f3f1]">
                3&apos; PAM motif
              </label>
              <select
                id="pam-select"
                value={pam}
                onChange={(e) => setPam(e.target.value as PamType)}
                className="w-full rounded-lg border border-[#1b2b37] bg-[#070d12] px-3 py-2.5 text-xs font-mono text-[#e8f3f1] focus:border-[#2ee6c5] focus:outline-none"
              >
                {(Object.keys(SUPPORTED_PAMS) as PamType[]).map((key) => (
                  <option key={key} value={key}>
                    {SUPPORTED_PAMS[key].label}
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-[#8aa4ad]">{SUPPORTED_PAMS[pam].description}</p>
            </div>

            {/* Max Mismatches Slider */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <label htmlFor="mm-slider" className="font-medium text-[#e8f3f1] flex items-center gap-1.5">
                  <SlidersHorizontal className="w-3.5 h-3.5 text-[#2ee6c5]" aria-hidden="true" />
                  Max mismatches allowed
                </label>
                <span className="font-mono font-semibold text-[#2ee6c5] tabular-nums">
                  {maxMm} bp
                </span>
              </div>
              <input
                id="mm-slider"
                type="range"
                min={0}
                max={6}
                step={1}
                value={maxMm}
                onChange={(e) => setMaxMm(Number(e.target.value))}
                className="w-full accent-[#2ee6c5] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] font-mono text-[#8aa4ad]">
                <span>0 (exact)</span>
                <span>2</span>
                <span>4</span>
                <span>6</span>
              </div>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            {errorMsg && (
              <div
                role="alert"
                className="rounded-lg border border-[#ff4d6d]/60 bg-[#ff4d6d]/10 px-3 py-2.5 text-xs text-[#ffb3c1] flex items-start gap-2"
              >
                <AlertCircle className="w-4 h-4 text-[#ff4d6d] shrink-0 mt-0.5" aria-hidden="true" />
                <span>{errorMsg}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-semibold gw-gradient-btn disabled:opacity-60 cursor-pointer"
            >
              <Play className="w-4 h-4" aria-hidden="true" />
              {loading ? 'Analyzing sequence...' : 'Run deterministic simulation'}
            </button>
          </div>
        </form>

        {/* Right 3D Simulation Viewport */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          <DnaHelixViewport
            dna={analysis?.dna || TEST_VECTOR.dna}
            sites={analysis?.sites || []}
            selectedSiteIndex={selectedSiteIdx}
            onSelectSite={(idx) => setSelectedSiteIdx(idx)}
            mode="simulator"
            autoPlay={autoPlay3D}
            className="flex-1 min-h-[460px] lg:min-h-[540px]"
          />
        </div>
      </div>

      {/* Sequence Statistics Strip */}
      {analysis && (
        <section aria-label="Sequence statistics" className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
          <div className="gw-panel px-4 py-3">
            <div className="text-xs text-[#8aa4ad]">Length</div>
            <div className="text-xl font-mono font-semibold text-[#e8f3f1] tabular-nums mt-0.5">
              {analysis.stats.length} <span className="text-xs text-[#8aa4ad]">bp</span>
            </div>
          </div>
          <div className="gw-panel px-4 py-3">
            <div className="text-xs text-[#8aa4ad]">GC Content</div>
            <div className="text-xl font-mono font-semibold text-[#2ee6c5] tabular-nums mt-0.5">
              {analysis.stats.gcPercent.toFixed(1)}
              <span className="text-xs text-[#8aa4ad]">%</span>
            </div>
          </div>
          <div className="gw-panel px-4 py-3">
            <div className="text-xs text-[#ff5d8f]">Adenine (A)</div>
            <div className="text-xl font-mono font-semibold text-[#e8f3f1] tabular-nums mt-0.5">
              {analysis.stats.counts.A}
            </div>
          </div>
          <div className="gw-panel px-4 py-3">
            <div className="text-xs text-[#ffb020]">Thymine (T)</div>
            <div className="text-xl font-mono font-semibold text-[#e8f3f1] tabular-nums mt-0.5">
              {analysis.stats.counts.T}
            </div>
          </div>
          <div className="gw-panel px-4 py-3">
            <div className="text-xs text-[#3ddc84]">Guanine (G)</div>
            <div className="text-xl font-mono font-semibold text-[#e8f3f1] tabular-nums mt-0.5">
              {analysis.stats.counts.G}
            </div>
          </div>
          <div className="gw-panel px-4 py-3">
            <div className="text-xs text-[#4cc9ff]">Cytosine (C)</div>
            <div className="text-xl font-mono font-semibold text-[#e8f3f1] tabular-nums mt-0.5">
              {analysis.stats.counts.C}
            </div>
          </div>
        </section>
      )}

      {/* Interactive 2D Duplex Coordinate Map */}
      {analysis && (
        <section className="gw-panel p-5 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-lg font-semibold text-[#e8f3f1]">
                Target Region Map (1-based original strand)
              </h2>
              <p className="text-xs text-[#8aa4ad]">
                Click any site block to center the 3D Cas9 scanner and inspect base alignment.
              </p>
            </div>
            <div className="text-xs font-mono text-[#8aa4ad]">
              Run #{analysis.runId} · {analysis.sites.length} site(s) found
            </div>
          </div>

          <div className="relative rounded-lg border border-[#1b2b37] bg-[#070d12] p-4 space-y-4">
            {/* Forward (+) Track */}
            <div className="space-y-1.5">
              <div className="text-[11px] font-mono text-[#8aa4ad]">Forward strand (+) 5&apos; → 3&apos;</div>
              <div className="relative h-8 rounded bg-[#0e1922] border border-[#1b2b37] overflow-hidden">
                {analysis.sites.map((site, idx) => {
                  if (site.strand !== '+') return null;
                  const leftPct = ((site.start - 1) / analysis.dna.length) * 100;
                  const widthPct = Math.max(2, ((site.end - site.start + 1) / analysis.dna.length) * 100);
                  const isSelected = idx === selectedSiteIdx;
                  const bg = !site.pamOk
                    ? 'bg-[#64748b]'
                    : site.mismatches === 0
                    ? 'bg-[#3ddc84]'
                    : site.mismatches <= 2
                    ? 'bg-[#ffb020]'
                    : 'bg-[#ff4d6d]';
                  return (
                    <button
                      key={`map-fwd-${idx}`}
                      type="button"
                      onClick={() => setSelectedSiteIdx(idx)}
                      style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                      title={`+ ${site.start}-${site.end} | ${site.mismatches} MM | PAM ${site.pam} | Est. Score ${site.score.toFixed(1)}`}
                      className={`absolute top-1 bottom-1 rounded text-[10px] font-mono font-bold text-[#070d12] flex items-center justify-center cursor-pointer transition-transform ${bg} ${
                        isSelected ? 'ring-2 ring-white scale-[1.03] z-10' : 'opacity-85 hover:opacity-100'
                      }`}
                    >
                      {site.score.toFixed(0)}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Reverse (-) Track */}
            <div className="space-y-1.5">
              <div className="text-[11px] font-mono text-[#8aa4ad]">Reverse complement (-) 3&apos; ← 5&apos;</div>
              <div className="relative h-8 rounded bg-[#0e1922] border border-[#1b2b37] overflow-hidden">
                {analysis.sites.map((site, idx) => {
                  if (site.strand !== '-') return null;
                  const leftPct = ((site.start - 1) / analysis.dna.length) * 100;
                  const widthPct = Math.max(2, ((site.end - site.start + 1) / analysis.dna.length) * 100);
                  const isSelected = idx === selectedSiteIdx;
                  const bg = !site.pamOk
                    ? 'bg-[#64748b]'
                    : site.mismatches === 0
                    ? 'bg-[#3ddc84]'
                    : site.mismatches <= 2
                    ? 'bg-[#ffb020]'
                    : 'bg-[#ff4d6d]';
                  return (
                    <button
                      key={`map-rev-${idx}`}
                      type="button"
                      onClick={() => setSelectedSiteIdx(idx)}
                      style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                      title={`- ${site.start}-${site.end} | ${site.mismatches} MM | PAM ${site.pam} | Est. Score ${site.score.toFixed(1)}`}
                      className={`absolute top-1 bottom-1 rounded text-[10px] font-mono font-bold text-[#070d12] flex items-center justify-center cursor-pointer transition-transform ${bg} ${
                        isSelected ? 'ring-2 ring-white scale-[1.03] z-10' : 'opacity-85 hover:opacity-100'
                      }`}
                    >
                      {site.score.toFixed(0)}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-between text-[11px] font-mono text-[#8aa4ad]">
              <span>1 bp</span>
              <span>{Math.round(analysis.dna.length / 2)} bp</span>
              <span>{analysis.dna.length} bp</span>
            </div>
          </div>
        </section>
      )}

      {/* Results Dashboard Table */}
      {analysis && (
        <section className="gw-panel overflow-hidden">
          <div className="px-5 py-4 border-b border-[#1b2b37] flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-lg font-semibold text-[#e8f3f1]">
                Candidate Target Sites
              </h2>
              <p className="text-xs text-[#8aa4ad]">
                All scores are <strong className="text-[#e8f3f1]">educational estimates</strong> (not experimentally validated). Formula: 100 × exp(-0.5 × penalty) when PAM is valid.
              </p>
            </div>
            <div className="text-xs font-mono text-[#2ee6c5]">
              Valid PAM hits: {analysis.summary.validPamSites} · Perfect matches: {analysis.summary.perfectMatches}
            </div>
          </div>

          {analysis.sites.length === 0 ? (
            <div className="p-8 text-center text-sm text-[#8aa4ad]">
              No sites matched within ≤ {analysis.max_mm} mismatches on either strand. Try increasing Max mismatches or switching the PAM motif.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-[#1b2b37] bg-[#070d12] text-xs font-medium text-[#8aa4ad]">
                    <th className="py-3 px-4">Strand</th>
                    <th className="py-3 px-4">Coords (1-based)</th>
                    <th className="py-3 px-4">Mismatches</th>
                    <th className="py-3 px-4">Mismatch Pos</th>
                    <th className="py-3 px-4">PAM &amp; Status</th>
                    <th className="py-3 px-4">Cut Site</th>
                    <th className="py-3 px-4 text-right">Educational Estimate</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1b2b37]">
                  {analysis.sites.map((site, idx) => {
                    const isSelected = idx === selectedSiteIdx;
                    const scoreColor = !site.pamOk
                      ? 'text-[#8aa4ad]'
                      : site.mismatches === 0
                      ? 'text-[#3ddc84]'
                      : site.mismatches <= 2
                      ? 'text-[#ffb020]'
                      : 'text-[#ff4d6d]';
                    return (
                      <tr
                        key={`${site.strand}-${site.start}-${idx}`}
                        onClick={() => setSelectedSiteIdx(idx)}
                        className={`cursor-pointer transition-colors ${
                          isSelected ? 'bg-[#2ee6c5]/10' : 'hover:bg-[#070d12]/60'
                        }`}
                      >
                        <td className="py-3 px-4 font-mono text-xs text-[#e8f3f1]">
                          {site.strand === '+' ? '+ (forward)' : '- (reverse)'}
                        </td>
                        <td className="py-3 px-4 font-mono text-xs text-[#e8f3f1] tabular-nums">
                          {site.start}–{site.end}
                        </td>
                        <td className="py-3 px-4 font-mono text-xs tabular-nums">
                          <span className={site.mismatches === 0 ? 'text-[#3ddc84]' : 'text-[#ffb020]'}>
                            {site.mismatches}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-mono text-xs text-[#c7d8d6]">
                          {site.mismatchPositions.length > 0
                            ? `guide ${site.mismatchPositions.join(', ')}`
                            : 'None (exact)'}
                        </td>
                        <td className="py-3 px-4 font-mono text-xs">
                          <span className="text-[#b7a6ff] font-semibold mr-2">{site.pam}</span>
                          {site.pamOk ? (
                            <span className="text-[#3ddc84] inline-flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" aria-hidden="true" />
                              Valid
                            </span>
                          ) : (
                            <span className="text-[#8aa4ad]">No PAM</span>
                          )}
                        </td>
                        <td className="py-3 px-4 font-mono text-xs text-[#e8f3f1] tabular-nums">
                          {site.pamOk ? `after ${site.cut}` : 'No cut'}
                        </td>
                        <td className={`py-3 px-4 font-mono text-sm font-semibold text-right tabular-nums ${scoreColor}`}>
                          {site.score.toFixed(1)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}

      {/* Alignment & Hypothetical Edit Panels */}
      {analysis && (
        <div className="space-y-6">
          <SequenceAlignmentView site={selectedSite} pamPattern={analysis.pam} />
          <HypotheticalEditPanel dna={analysis.dna} site={selectedSite} />
        </div>
      )}
    </div>
  );
};
